-------------------------------------------------------------------------------
-- this is the 'paper' implementation, supporting only base 16 (b = 4)
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- modules
-------------------------------------------------------------------------------
require"splay.base"
rpc = require"splay.rpc"
crypto = require"crypto"
time = misc.time


-------------------------------------------------------------------------------
-- global variables + initializations + other settings
-------------------------------------------------------------------------------
max_time = 2600
bytesSent, bytesReceived = 0, 0
b, leaf_size, bits = 4, 16, 128
key_size = math.log(2^bits)/ math.log(2^b)
if key_size < 2^b then
	print("Key size must be greater or equal than base")
	os.exit()
end
if b ~= 4 then
	print("b must be 4, because base 16 (hexadecimal) is needed in one function.")
	os.exit()
end

-- to test locally
if not job then
    if arg and #arg < 4 then
        print("Usage: "..arg[0].." <IP> <port> <number_of_nodes> <my_position>")
        os.exit()
    end

    local arg_ip = arg[1]
    local arg_port_start = tonumber(arg[2])
    local arg_num_nodes = tonumber(arg[3])
    local arg_my_pos = tonumber(arg[4])

    job = {
        me = { ip   = arg_ip,
               port = arg_port_start + arg_my_pos},
        position = arg_my_pos,
        nodes = {}
    }

    for i = 1, arg_num_nodes do
        table.insert(job.get_live_nodes(), {ip = arg_ip, port = arg_port_start + i})
    end
end

-- current node
me = {}
me = job.me
function compute_id(o) return string.sub(crypto.evp.new("sha1"):digest(o), 1, bits / 4) end
me.id = compute_id(me.ip..me.port)
print("ME: "..me.id)

rdv = job.get_live_nodes()[1]

-- routing table
routing_table = {}
for i = 0, key_size - 1 do routing_table[i] = {} end

leaves_decreasing = {}
leaves_increasing = {}
ideal_leaves_increasing = {}
ideal_leaves_decreasing = {}

g_timeout, activity_time, check_time, ping_refresh = 60, 5, 10, 125 -- on planetlab: 60, 25, 20, 125
ping_c, actions, fails_count = {}, 0, 0
insert_l, repair_l = events.lock(), events.lock()
L_l, ping_c_l = events.lock(), events.lock()

-------------------------------------------------------------------------------
-- global variables + initializations + other settings
-------------------------------------------------------------------------------

function num(k)
	if k.id then return tonumber("0x"..k.id) else return tonumber("0x"..k) end
end

function diff(key1, key2)
	local k1, k2, a, b = num(key1), num(key2)
	if k1 < k2 then a, b = k2, k1 else a, b = k1, k2 end
	return math.min(a - b, 2^bits - a + b)
end

function shared_prefix_length(a, b)
	for i = 1, key_size do
		if string.sub(a, i, i) ~= string.sub(b, i, i) then return i - 1 end
	end
	return key_size
end

function row_col(key)
	local row = shared_prefix_length(key, me.id)
	return row, num(string.sub(key, row + 1, row + 1))
end

-- calculate "distance" (network proximity) to another node
function ping(n, no_c)
	ping_c_l:lock()
	if not (not no_c and ping_c[n.id] and ping_c[n.id].last > time() - ping_refresh) then
	 	local t = time()
		if rpc.ping(n, g_timeout) then
			ping_c[n.id] = {last = time(), value = true, time = time() - t}
		else
			ping_c[n.id] = {last = time(), value = false, time = math.huge}
			failed(n)
		end
	end
	local v, t = ping_c[n.id].value, ping_c[n.id].time
	ping_c_l:unlock()
	return v, t
end

-- called in insert_route() only, ping is always cached.
function distance(n)
	local v, t = ping(n)
	return t
end

-- check if a node from the leaves set could go into the routing table
function already_in(node)
	if node.id == me.id then return true end
	for _, n in pairs(leaves()) do
		if n.id == node.id then return true end
	end
	if range_leaf(node.id) then return false end
	for r = 0, key_size - 1 do
		for c = 0, key_size - 1 do
			if routing_table[r][c] and routing_table[r][c].id == node.id then
				return true
			end
		end
	end
end

function insert(node, notify)
    events.thread(function() insert_t(node, notify) end)
end

function insert_t(node, notify)
	insert_l:lock()
	if already_in(node) or (not notify and not ping(node)) then
        -- nothing
 	else
		local r1, r2 = insert_leaf(node), insert_route(node)
		if (r1 or r2) and not notify then
			events.thread(function()
				local r = rpc.call(node, {'notify', me}, g_timeout)
				if r then return true else failed(node) end
			end)
		end
	end
	insert_l:unlock()
end

function insert_route(node)
	local row, col = row_col(node.id)
	local r = routing_table[row][col]
	-- if the slot is empty, or there is another node that is more distant,
	-- we put the new node in the routing table
	if not r then
		routing_table[row][col] = node
		return true
	else
		if r.id ~= node.id and distance(node) < distance(r) then
			routing_table[row][col] = node
			return true
		else
			return false
		end
	end
end

function insert_leaf(node)
	L_l:lock()
	local r1, r2 = insert_one_leaf(node, leaves_decreasing, false), insert_one_leaf(node, leaves_increasing, true)
	L_l:unlock()
	return r1 or r2
end

function insert_one_leaf(node, leaf, sup)
	for i = 1, leaf_size / 2 do
		if leaf[i] then
			if node.id == leaf[i].id then break end
			if (not sup and misc.between_c(num(node), num(leaf[i]), num(me))) or
				(sup and misc.between_c(num(node), num(me), num(leaf[i]))) then
				table.insert(leaf, i, node)
				while #leaf > leaf_size / 2 do table.remove(leaf) end
				return i
			end
		else
			leaf[i] = node
			return i
		end
	end
	return false
end

function leaves()
	L_l:lock()
	local L = misc.dup(leaves_decreasing)
	for _, e in pairs(leaves_increasing) do
		local found = false
		for _, e2 in pairs(leaves_decreasing) do
			if e.id == e2.id then found = true break end
		end
		if not found then L[#L + 1] = e end
	end
	L_l:unlock()
	return L
end

-- including self in the range
function range_leaf(D)
	local min, max = num(me), num(me)
	L_l:lock()
	if #leaves_decreasing > 0 then min = num(leaves_decreasing[#leaves_decreasing]) end
	if #leaves_increasing > 0 then max = num(leaves_increasing[#leaves_increasing]) end
	L_l:unlock()
	return misc.between_c(num(D), min - 1, max + 1)
end

function nearest(D, nodes)
	local d, j = math.huge, nil
    for i, n in pairs(nodes) do
		if diff(D, n) < d then
			d = diff(D, n)
			j = i
		end
	end
	return nodes[j]
end

function repair(row, col, id)
	repair_l:lock()
	if not routing_table[row][col] then
		local r = row
		while r <= key_size - 1 and not repair_from_row(r, row, col, id) do r = r + 1 end
	end
	repair_l:unlock()
end

-- use row 'r' to contact a node that could give us a replacement for the node 
-- at pos (row; col)
-- id: to avoid re-inserting the same failed node
function repair_from_row(r, row, col, id)
	for c, node in pairs(routing_table[r]) do
		if c ~= col then
			local ok, r = rpc.acall(node, {'get_node', row, col}, g_timeout)
			-- do not accept the same broken node
			if ok then
				r = r[1]
				if r and r.id ~= id then
					if ping(r, true) then
						insert(r)
						log:print("Node repaired with "..r.id.." "..r.ip..":"..r.port)
						return true
					end
				end
			else
				failed(node)
			end
		end
	end
end

function failed(node)
    events.thread(function() failed_t(node) end)
end

function failed_t(node)
	-- update cache
	ping_c_l:lock()
	ping_c[node.id] = {last = time(), value = false, time = math.huge}
	ping_c_l:unlock()
	-- clean leaves
	L_l:lock()
	for i, n in pairs(leaves_decreasing) do if node.id == n.id then table.remove(leaves_decreasing, i) end end
	for i, n in pairs(leaves_increasing) do if node.id == n.id then table.remove(leaves_increasing, i) end end
	L_l:unlock()
	local row, col = row_col(node.id)
	if routing_table[row][col] and routing_table[row][col].id == node.id then
		routing_table[row][col] = nil
		repair(row, col, node.id)
	end
end

function join(node)
    log:print("joining...")
	local r, err = rpc.call(node, {'route', {typ = "#join#"}, me.id})
	if not r then return nil, err end
	for _, e in pairs(r) do
		if e.id then
			log:print("received node "..e.id.." "..e.ip..":"..e.port) --commented by JV
			insert(e)
		end
	end
	return true
end

function try_route(msg, key, T)
	msg.count_hops = msg.count_hops+1
	--local msg, T, reply = forward(msg, key, T)

	--if not T then return reply end
	log:print("try_route routing "..key.." to host "..T.id.." "..T.ip..":"..T.port)
	local ok, n = rpc.acall(T, {'route', msg, key}, g_timeout)
	if ok then
		if n[1] then
			if msg.typ == "#join#" then
				local row, col = row_col(key)
				for _, node in pairs(routing_table[row]) do
					local found = false
					for _, j in pairs(n[1]) do
						if j.id == node.id then
							found = true
							break
						end
					end
					if not found then
						table.insert(n[1], node)
					end
				end
			end
			return unpack(n)
		else
			return nil
		end
	else 
		failed(T)
		log:print("cannot route through "..T.id)
	end
end

function route(msg, key, no_count_action) -- Pastry API
	if not no_count_action then actions = actions + 1 end
	if not msg.time then msg.time = tostring(misc.time()) end

	-- security
	if not msg.count_hops then msg.count_hops = 0 end
	--msg.count_hops = msg.count_hops + 1
	if msg.count_hops > 15 then
		log:warn("Problem routing "..key.." max hops reached")
		return nil, "routing problem max hops reached: "..key
	end

	if msg.typ == "#test#" then
		if not msg.count then msg.count = 0 else msg.count = msg.count + 1 end
		if not msg.trace then msg.trace = "" end
		if not msg.hops then msg.hops = {me} else table.insert(msg.hops, me) end
	end

	if key ~= me.id then
		if range_leaf(key) then
			local n = nearest(key, leaves())
			if diff(n, key) < diff(me, key) then
				return try_route(msg, key, n)
			end
		else
			local row, col = row_col(key)
			if routing_table[row][col] then
				return try_route(msg, key, routing_table[row][col])
			else
				for r = row, key_size - 1 do 
					for _, n in pairs(routing_table[r]) do
						if diff(n, key) < diff(me, key) then
							return try_route(msg, key, n)
						end
					end
				end
				for _, n in pairs(leaves()) do
					if shared_prefix_length(n.id, key) >= row and diff(n, key) < diff(me, key) then
						return try_route(msg, key, n)
					end
				end
			end
		end
	end
	
	if msg.typ == "#join#"
		then return {me, unpack(leaves())}
	else
		return me, receive(msg, key)
	end
end

function do_leaf(node)
	local r = rpc.call(node, 'leaves', g_timeout)
	if r then
		for _, n in pairs(r) do insert(n) end
	else
		failed(node)
	end
end

function check_daemon()
	local pos = 1
	while events.sleep(check_time) do
		local L = leaves()
		if pos < #L then pos = pos + 1 else pos = 1 end
		if L[pos] then do_leaf(L[pos]) end
	end
end

function get_node(row, col)
    return routing_table[row][col]
end

function notify(node)
    insert(node, true) 
    return true
end

-- Pastry API
function send(msg, node)
    return rpc.call(node, {'route', msg, node.id})
end 

-- Pastry API (must override)
function forward(msg, key, T) 
	if msg.typ == "#publish#" then 
	    -- do something with the msg
	end
	return msg, T 
end


function receive (msg, key)
	if msg.typ == "#test#" then
	if msg.origin then rpc.call(msg.origin, {'delivered', key, me, msg.count_hops, msg.time}) end
	end
end

function delivered(key, dest, hops, time_start)
		local time_end = misc.time()
		local elapsed = time_end - tonumber(time_start)
		local msg = table.concat({"LOOKUP_END "..key.." KEY_OWNER "..dest.id.." HOPS "..hops.." HOPS ".." DELAY "..elapsed})
		log:print(msg)
end


function hash_all()
	local ids = {}
	for i,v in ipairs(job.get_live_nodes()) do
		if not same_node(v,me) then ids[#ids+1] = compute_id(v.ip..v.port) end
	end
	return ids
end

function kill()
	events.sleep(10)
	os.exit()
end

r_d = {}
function ring(m)
	if r_d[m.msg] then
		log:print("RING: "..m.msg.." already")
		rpc.call(m.origin, {'delivered', m})
	else
		r_d[m.msg] = m.msg
		log:print("RING: "..m.msg)
		m.count = m.count + 1
		-- check leaves
		local e_c = 0
		for i, le in pairs(m.leaves) do
			if not leaves_decreasing[i] then break end
			if leaves_decreasing[i].id ~= le.id then
				e_c = e_c + 1
			end
		end
		if e_c > 0 then
			events.thread(function() rpc.call(m.origin, {'leaf_error', m, me, e_c}) end)
		end
		if leaves_increasing[1] then
			table.insert(m.leaves, 1, me)
			while #m.leaves > leaf_size / 2 do table.remove(m.leaves) end
			events.thread(function()
				if not rpc.acall(leaves_increasing[1], {'ring', m}) then
					rpc.call(m.origin, {'next_error', m, me, leaves_increasing[1]})
				end
			end)
		else
			rpc.call(m.origin, {'delivered', m})
			log:print("RING: "..m.msg.." empty leaf")
			return me.id.."\nempty leaf"
		end
	end
end

function display_route_table()
	local out = ""
	for i = 0, key_size / 4 do
		local str = ""..i..": "
		for c = 0, 2^b - 1 do
			if routing_table[i][c] then
				str = str.." "..routing_table[i][c].id
			else
				str = str.." -"
			end
		end
		out = out..str.."\n"
	end
	return out
end

function display_leaf()
	local out = ""
	for i = #leaves_decreasing, 1, -1 do
		if leaves_decreasing[i] then
			out = out.." "..leaves_decreasing[i].id
		end
	end
	out = out.." ["..me.id.."]"
	for i = 1, #leaves_increasing do
		if leaves_increasing[i] then
			out = out.." "..leaves_increasing[i].id
		end
	end
	return out
end

function display_ideal_leaf()
	local out = ""
	for i = #ideal_leaves_decreasing, 1, -1 do
		if ideal_leaves_decreasing[i] then
			out = out.." "..ideal_leaves_decreasing[i]
		end
	end
	out = out.." ["..me.id.."]"
	for i = 1, #ideal_leaves_increasing do
		if leaves_increasing[i] then
			out = out.." "..ideal_leaves_increasing[i]
		end
	end
	return out
end

function socket_stats()
	if socket.stats then
		return socket.stats()
	end
end

function debug()
	if socket.infos then
		socket.infos()
	end
	if events.stats then
		print(events.stats())
	end

	log:print("_________________________________________")
	collectgarbage()
	log:print(gcinfo().." ko")
	log:print("ME: "..me.id)
	log:print(display_route_table())
	log:print(display_leaf())
	log:print("_________________________________________")
	print()

end

-------------------------------------------------------------------------------
-- Convergence
-------------------------------------------------------------------------------
OPT_ENTRIES = 0
rt_lock = events.lock()
de_leaves_lock = events.lock()
in_leaves_lock = events.lock()

function same_node(n1,n2)
	local peer_first
	if n1.peer then peer_first = n1.peer else peer_first = n1 end
	local peer_second
	if n2.peer then peer_second = n2.peer else peer_second = n2 end
	return peer_first.port == peer_second.port and peer_first.ip == peer_second.ip
end


function diff_clock(key1, key2)
	local k1, k2 = num(key1), num(key2)
	if k1 < k2 then return k2 - k1 else return 2^bits - k1 + k2 end
end

function rank_clockwise(t,partner)
		table.sort(t, function (a,b) return diff_clock(partner,a) < diff_clock(partner,b) end)
end

function precompute_leaves(ids)
	ideal_leaves_increasing, ideal_leaves_decreasing = {},{}		 
	rank_clockwise(ids,me)
	for i = 1, leaf_size/2 do
		table.insert(ideal_leaves_increasing, ids[i])
	end
	for i = #ids, #ids-leaf_size/2+1, -1 do
		table.insert(ideal_leaves_decreasing, ids[i])
	end
end
	
function precompute_routing_table(ids)
	ideal_routing_table = {}
	OPT_ENTRIES = 0
	for i = 0, key_size - 1 do
		ideal_routing_table[i] = {}
	end
	for i,v in ipairs(ids) do
		local row, col = row_col(v)
		if row and col then
			if ideal_routing_table[row][col] then --column is not empty
				table.insert(ideal_routing_table[row][col], v)
			else
				ideal_routing_table[row][col] = {}
				table.insert(ideal_routing_table[row][col], v)
				OPT_ENTRIES = OPT_ENTRIES + 1
			end
		end
	end
end
	
function precompute_views() 
	local ids = hash_all()
	precompute_leaves(ids)
	precompute_routing_table(ids)
	end
		
function check_convergence()
	local errors_rt, errors_l = 0,0
--check prefix table
	rt_lock:lock()
	for i = 0, key_size/4 do
		for j = 0, 2^b-1 do
			if not routing_table[i][j] then
					if ideal_routing_table[i][j] then
						errors_rt = errors_rt+1 
					end
			else --the row/col in rt is not empty
				local correct = false
				if ideal_routing_table[i][j] then 				
					for k = 1, #ideal_routing_table[i][j] do
						if routing_table[i][j].id == ideal_routing_table[i][j][k]	 then
							correct = true
							break
						end
					end
					if not correct then errors_rt = errors_rt+1 end
				end
			end
		end
	end
	rt_lock:unlock()	
--check leaf sets
	de_leaves_lock:lock()
	for i = 1, leaf_size/2 do
		if leaves_decreasing[i] then
			if leaves_decreasing[i].id ~= ideal_leaves_decreasing[i] then errors_l = errors_l + 1 end
		else errors_l = errors_l + 1 end
	end
	de_leaves_lock:unlock()

	in_leaves_lock:lock()
	for i = 1, leaf_size/2 do
		if leaves_increasing[i] then
			if leaves_increasing[i].id ~= ideal_leaves_increasing[i] then errors_l = errors_l + 1 end
		else errors_l = errors_l + 1 end		 
	end
	in_leaves_lock:unlock()
	local mand = (leaf_size-errors_l)/(leaf_size/100)
	local opt = (OPT_ENTRIES-errors_rt)/(OPT_ENTRIES/100)		
	log:print(table.concat({"CURRENT_VIEW_STATE ",me.id," mandatory ",mand," optional ", opt," bytes_sent ",bytesSent," bytes_received ",bytesReceived}))
end
	

-------------------------------------------------------------------------------
-- Lookup
-------------------------------------------------------------------------------

function lookup_test()
	local key = compute_id(math.random(100000000))	
	log:print("LOOKUP_START ".. key)
	route({typ = "#test#", origin = me}, key, false)
end

function converge_test()
	precompute_views()
	resource_stats()
	check_convergence()
	--log:print(display_leaf())
	--log:print(display_ideal_leaf())
end

-- if no activity, create artificial one to detect route failures
function activity()
	if actions == 0 then
		local key = compute_id(math.random(1, 1000000000))
		log:print("activity msg: "..key)
		events.thread(function() route({typ = "#activity#"}, key, true) end)
	end
	actions = 0
end

function resource_stats()
	local ts,tr = socket.stats()
	local tot_KB_sent=misc.bitcalc(ts).kilobytes
	local tot_KB_recv=misc.bitcalc(tr).kilobytes
	bytesSent = tot_KB_sent
	bytesReceived = tot_KB_recv
end

function terminator()
  events.sleep(max_time)
  os.exit()
end

function runPastry()
	me.id = compute_id(me.ip..tostring(me.port))
	
	--events.thread(terminator)
	
	if not rpc.server(me.port) then
		log:error("RPC bind error: "..me.port)
		return
	end
	log:print("UP: "..me.ip..":"..me.port)

	if job then
		local time = job.position
		events.sleep(10 + time / 2)

		local try = 0
		local ok, err = join(rdv)
		while not ok do
			try = try + 1
			if try <= 3 then
				log:print("Cannot join "..rdv.ip..":"..rdv.port..": "..tostring(err).." => try again")
				events.sleep(math.random(try * 30, try * 60))
				ok, err = join(rdv)
			else
				log:print("Cannot join "..rdv.ip..":"..rdv.port..": "..tostring(err).."  => end")
				os.exit()
			end
		end
	end
	log:print("START: "..me.id)
	
	--events.periodic(activity_time, activity)
	--debug_thread = events.periodic(30, debug)
	events.thread(function() check_daemon() end)
	converge_test_thread = events.periodic(3,converge_test)
	lookup_test_thread = events.periodic(3,lookup_test)
end

-- start pastry
events.thread(runPastry)
events.loop()

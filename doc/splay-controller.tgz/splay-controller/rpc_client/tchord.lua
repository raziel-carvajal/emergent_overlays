-------------------------------------------------------------------------------
-- modules
-------------------------------------------------------------------------------

require"splay.base"
rpc = require"splay.rpc"
rpc.l_o.level=1
misc = require "splay.misc"
crypto = require "crypto"

-- addition to allow local run
PARAMS={}
local cmd_line_args=nil
if not job then --outside the sandbox
	if #arg < 2 then  
		print("lua ", arg[0], " my_position nb_nodes")  
		os.exit()  
	else  		
		local pos, total = tonumber(arg[1]), tonumber(arg[2])  
		local utils = require("splay.utils")
		job = utils.generate_job(pos, total, 20001) 
		cmd_line_args=arg[3]	
	end
end

if arg~=nil then
	if cmd_line_args==nil then cmd_line_args=arg[1] end
	if cmd_line_args~=nil and cmd_line_args~="" then
		print("ARGS: ",cmd_line_args)	
		for _,v in pairs(misc.split(cmd_line_args,":")) do
			local t=misc.split(v,"=")
			PARAMS[t[1]]=t[2]
		end
	end
end


rpc.server(job.me.port)
-------------------------------------------------------------------------------
-- current node
-------------------------------------------------------------------------------
--current nodes's id
me = {}
me.peer = job.me
M = 32
function compute_hash(o)
	return tonumber(string.sub(crypto.evp.new("sha1"):digest(o), 1, M/4), 16)
end

--current node's age
me.age = 0
me.id = compute_hash(table.concat({tostring(job.me.ip),":",tostring(job.me.port)}))

-------------------------------------------------------------------------------
-- parameters
-------------------------------------------------------------------------------
max_time = 1000

--T-CHORD params
GOSSIP_TIME = tonumber(PARAMS["GOSSIP_TIME"]) or 5
TCHORD_EXPONENT = 20
TCHORD_LEAF = tonumber(PARAMS["TCHORD_LEAF"]) or 3
TCHORD_VIEW_SIZE = tonumber(PARAMS["TCHORD_VIEW_SIZE"]) or 6

TCHORD_CONVERGE = tonumber(PARAMS["TCHORD_CONVERGE"]) or true
TCHORD_CHURN = tonumber(PARAMS["TCHORD_CONVERGE"]) or true
TCHORD_LOOKUP = tonumber(PARAMS["TCHORD_CONVERGE"]) or false

TCHORD_HB_TIMEOUT = tonumber(PARAMS["TCHORD_HB_TIMEOUT"]) or 10 --100 without churn
TCHORD_PARTNER_SELECT = tonumber(PARAMS["TCHORD_PARTNER_SELECT"]) or 0
TCHORD_MESSAGE_SIZE = tonumber(PARAMS["TCHORD_MESSAGE_SIZE"]) or 10

--PSS params
PSS_VIEW_SIZE =tonumber(PARAMS["PSS_VIEW_SIZE"]) or 6
PSS_SHUFFLE_SIZE =  tonumber(PARAMS["PSS_SHUFFLE_SIZE"]) or math.floor(PSS_VIEW_SIZE / 2 + 0.5)
PSS_SHUFFLE_PERIOD = tonumber(PARAMS["PSS_SHUFFLE_PERIOD"]) or 3 --5 without churn


-- ############################################################################
-- 	Peer Sampling Service
-- ############################################################################

PSS = {

	view = {},
	view_copy = {},
	c = PSS_VIEW_SIZE,
	exch = PSS_SHUFFLE_SIZE,
	H = 1,
	S = math.floor(PSS_VIEW_SIZE/ 2 + 0.5) - 1,
	SEL = "rand", -- could also be "tail"
	view_copy_lock = events.lock(),
	
	-- utilities
	print_table = function(t)
		print("[ (size "..#t..")")
		for i=1,#t do
			print("  "..i.." : ".."["..t[i].peer.ip..":"..t[i].peer.port.."] - age: "..t[i].age.." - id: "..t[i].id)
		end
		print("]")
	end,
	
	set_of_peers_to_string = function(v)
		ret = ""; for i=1,#v do	ret = ret..v[i].id.." "	end
		return ret
	end,
	
	print_set_of_peers = function(v,message)	
		if message then log:print(message) end
		log:print(PSS.set_of_peers_to_string(v))
	end,
	
	print_view = function(message)
		if message then log:print(message) end
		log:print("PSS VIEW_CONTENT "..job.position.." "..PSS.set_of_peers_to_string(PSS.view))
	end,
	
	-- peer sampling functions
	
	pss_selectPartner= function()
		if #PSS.view > 0 then
			if PSS.SEL == "rand" then return math.random(#PSS.view) end
			if PSS.SEL == "tail" then
				local ret_ind = -1 ; local ret_age = -1
				for i,p in pairs(PSS.view) do
					if (p.age > ret_age) then ret_ind = i;ret_age=p.age end
				end
				assert (not (ret_ind == -1))
				return ret_ind
			end
		else return false end
	end,
	
	same_peer_but_different_ages = function(a,b)
		return a.peer.ip == b.peer.ip and a.peer.port == b.peer.port
	end,

	same_peer = function(a,b)
		return PSS.same_peer_but_different_ages(a,b) and a.age == b.age
	end,
	
	pss_selectToSend = function()

		-- create a new return buffer
		local toSend = {}
		-- append the local node view age 0
		table.insert(toSend,{peer={ip=job.me.ip,port=job.me.port},age=0,id=me.id})
		if #PSS.view > 0 then 
			-- shuffle view
			PSS.view = misc.shuffle(PSS.view)
			-- move oldest H items to the end of the view
			--- 1. copy the view
			local tmp_view = misc.dup(PSS.view)
			--- 2. sort the items based on the age
			table.sort(tmp_view,function(a,b) return a.age < b.age end)
			--- 3. get the H largest aged elements from the tmp_view, remove them from the view 
			---    (we assume there are no duplicates in the view at this point!)
			---    and put them at the end of the view
			for i=(#tmp_view-PSS.H+1),#tmp_view do
				local ind = -1
				for j=1,#PSS.view do
					if PSS.same_peer(tmp_view[i],PSS.view[j]) then ind=j; break end
				end
				assert (not (ind == -1))
				elem = table.remove(PSS.view,ind)
				PSS.view[#PSS.view+1] = elem
			end
	
			-- append the first exch-1 elements of view to toSend
			for i=1,(PSS.exch-1) do
				toSend[#toSend+1]=PSS.view[i]
			end
		end
		return toSend
	end,
	
	pss_selectToKeep = function(received)
		local selectToKeepStart= misc.time()	
		-- concatenate the view and the received set of view items
		for j=1,#received do PSS.view[#PSS.view+1] = received[j] end
		
		-- remove duplicates from view
		-- note that we can't rely on sorting the table as we need its order later
		local i = 1	
		while i < #PSS.view-1 do
			for j=i+1,#PSS.view do
				if PSS.same_peer_but_different_ages(PSS.view[i],PSS.view[j]) then
					-- delete the oldest
					if PSS.view[i].age < PSS.view[j].age then 
						table.remove(PSS.view,j)
					else
						table.remove(PSS.view,i)
					end
					i = i - 1 -- we need to retest for i in case there is one more duplicate
					break
				end
			end
			i = i + 1
		end
	
		-- remove the min(H,#view-c) oldest items from view
		local o = math.min(PSS.H,#PSS.view-PSS.c)
		while o > 0 do
			-- brute force -- remove the oldest
			local oldest_index = -1
			local oldest_age = -1
			for i=1,#PSS.view do 
				if oldest_age < PSS.view[i].age then
					oldest_age = PSS.view[i].age
					oldest_index = i
				end
			end
			assert (not (oldest_index == -1))
			table.remove(PSS.view,oldest_index)
			o = o - 1
		end
		
		-- remove the min(S,#view-c) head items from view
		o = math.min(PSS.S,#PSS.view-PSS.c)
		while o > 0 do
			table.remove(PSS.view,1) -- not optimal
			o = o - 1
		end
		
		-- in the case there still are too many peers in the view, remove at random
		while #PSS.view > PSS.c do table.remove(PSS.view,math.random(#PSS.view)) end
	
		assert (#PSS.view <= PSS.c)
		--log:print("PSS_SELECT_TO_KEEP ", ( misc.time() - selectToKeepStart ) )		
	end,
	
	ongoing_at_rpc=false,
	
	is_init = false,
	
	pss_passive_thread = function(from,buffer)
		if PSS.ongoing_at_rpc or not PSS.is_init then
			return false
		end
		
		--PSS.print_view("passive_thread ("..job.position.."): entering")
		--PSS.print_set_of_peers(buffer,"passive_thread ("..job.position.."): received from "..from)
		
		local ret = PSS.pss_selectToSend()
		PSS.pss_selectToKeep(buffer)
		--PSS.print_view("passive_thread ("..job.position.."): after selectToKeep")
		return ret
	end,
	
	pss_send_at_rpc = function(peer,pos,buf)
		local ok, r = rpc.acall(peer,{"PSS.pss_passive_thread", pos, buf},PSS_SHUFFLE_PERIOD/2)
		return ok,r
	end,
	
	pss_active_thread = function()
		PSS.ongoing_at_rpc=true
		-- select a partner
		local exchange_aborted=true
		local exchange_retry=5
		for i=1,exchange_retry do --up to 5 attemps per round, re-do in case of conflict 
			partner_ind = PSS.pss_selectPartner()
			local init_retry=0
			while not partner_ind do
				init_retry=init_retry+1
				if init_retry<=2 then
					log:print("pss_active_thread: pss view is empty, re-initialising the view")
					PSS.pss_init()
					partner_ind = PSS.pss_selectPartner()
				else break end
			end
			if not partner_ind then
				log:print("pss_active_thread: pss view is empty, no partner can be selected")
				return
			end
			partner = PSS.view[partner_ind]
			-- remove the partner from the view
			table.remove(PSS.view,partner_ind)
			-- select what to send to the partner
			buffer = PSS.pss_selectToSend()
			--PSS.print_set_of_peers(buffer,"active_thread ("..job.position.."): sending to "..partner.id)

			-- send to the partner
			--local rpcStart=misc.time()
			local ok, r = PSS.pss_send_at_rpc(partner.peer,job.position, buffer) -- rpc.acall(partner.peer,{"PSS.pss_passive_thread", job.position, buffer},PSS_SHUFFLE_PERIOD/2)
			--log:print("PSS.pss_passive_thread.RPC ",  misc.time() - rpcStart  )
			if ok then
				-- select what to keep etc.
				local received = r[1]
				if received==false then
					log:print("PSS received false due to ongoing RPC or yet uninitialized view, will try again in a short while")
					events.sleep(math.random())	
					--the call was aborted due to pending RPC at peer's node
				else
					exchange_aborted=false 
					--PSS.print_set_of_peers(received,"active_thread ("..job.position.."): received from "..partner.id)
					PSS.pss_selectToKeep(received)
					--PSS.print_view("pss_active_thread ("..job.position.."): after selectToKeep")
				end
			else
				-- peer not replying? remove it from view!
				log:print("on peer ("..job.position..") peer "..partner.id.." did not respond -- removing it from the view")
				log:warning("PSS.pss_passive_thread RPC error:", r)
				table.remove(PSS.view,partner_ind)
			end		
			if exchange_aborted==false then break end
		end
		for _,v in ipairs(PSS.view) do
				v.age = v.age+1
		end
		PSS.view_copy_lock:lock()
		local viewCopyLock = misc.time()
		PSS.view_copy = misc.dup(PSS.view)
		--log:print("PSS_VIEW_COPY_LOCK_HELD ", ( misc.time() - viewCopyLock ) )
		PSS.view_copy_lock:unlock()
		-- now, allow to have an incoming passive thread request
		PSS.ongoing_at_rpc=false
	end,
	
	-- API
	pss_getPeer = function()
		PSS.view_copy_lock:lock()
		local getPeerLockHeldStart = misc.time()
		
		local peer = PSS.view_copy[math.random(#PSS.view_copy)] 

		--log:print("PSS_GET_PEER_LOCK_HELD_VIEW_COPY ", ( misc.time() - getPeerLockHeldStart ) )
		PSS.view_copy_lock:unlock()

		return peer
	end,

	pss_init = function()
		-- ideally, would perform a random walk on an existing overlay
		-- but here we emerge from the void, so let's use the Splay provided peers.
		-- Ages are taken randomly in [0..c] but could be 0 as well.
		local indexes = {}
		for i=1,#job.get_live_nodes() do indexes[#indexes+1]=i end
		table.remove(indexes,job.position) --remove myself
		local selected_indexes = misc.random_pick(indexes,math.min(PSS.c,#indexes))	
		for _,v in pairs(selected_indexes) do
				local a_peer = job.get_live_nodes()[v]
				local hashed_index = compute_hash(tostring(a_peer.ip) ..":"..tostring(a_peer.port))
		 		PSS.view[#PSS.view+1] = 
				{peer=a_peer,age=math.random(PSS.c),id=hashed_index}
		end
		PSS.view_copy = misc.dup(PSS.view)
		assert (#PSS.view == math.min(PSS.c,#indexes))
		PSS.print_view("initial view")
		PSS.is_init = true
	end,

	
	log_view = function()
		-- called once to log the view
		events.sleep(10.5*PSS_SHUFFLE_PERIOD)
		log:print("VIEW_CONTENT "..job.position.." "..PSS.set_of_peers_to_string(PSS.view))
	end,

}

-- ############################################################################
-- 	TCHORD
-- ############################################################################


TCHORD = {
	leaves = {},
	fingers = {},
	predecessor = nil,
	succ_view = {},
	pred_view = {},
	t = TCHORD_EXPONENT,
	l = TCHORD_LEAF,
	s = TCHORD_VIEW_SIZE,
	message_size = TCHORD_MESSAGE_SIZE,
	timeout = TCHORD_HB_TIMEOUT,
	leaves_lock = events.lock(),
	fingers_lock = events.lock(),
	pred_view_lock = events.lock(),
	succ_view_lock = events.lock(),
	pred_lock = events.lock(),
	cycle_succ = 0,
	cycle_pred = 0,
	cycle_succ_lock = events.lock(),
	cycle_pred_lock = events.lock(),
	ideal_fingers = {},
	ideal_leaves = {},
	ideal_predecessor = {},
	keys = {},
	responsible = {},
	view_init = false,
	
-------------------------------------------------------------------------------
-- debug
-------------------------------------------------------------------------------
	display_view = function(v, which)
 		local display = table.concat({which," VIEW_CONTENT ",me.id,"(", TCHORD.get_pos(me),"):"})
		for i,w in ipairs(v) do
			display = table.concat({display ," ",w.id,"(",TCHORD.get_pos(w),")"})
		end
		log:print(display)
	end,

	
	display_leaves = function(c) 
		local out = table.concat({"TCHORD_cycle", " ", c, " ", "APPROX_LEAVES ", job.position, " "})
		for i = 1, TCHORD.l do
			if TCHORD.leaves[i] then
				out = table.concat({out,"l",i,":",TCHORD.leaves[i].id,"(",TCHORD.get_pos(TCHORD.leaves[i]),")\t"})
			end
		end
		log:print(out)
	end,
	
	display_fingers = function(c) 
		local out = table.concat({"TCHORD_cycle", " ", c, " ", "APPROX_FINGERS ", job.position, " "})
		for i = 1, TCHORD.t do
			if TCHORD.fingers[i] then
				out = table.concat({out,"f",(i-1),":",TCHORD.fingers[i].id,"(",TCHORD.get_pos(TCHORD.fingers[i]),") "})
			end
		end
		log:print(out)
	end,

	debug = function(c)
		TCHORD.display_leaves(c)
		TCHORD.display_fingers(c)
	end,
	
	display_correct_fingers = function() 
		local display = "IDEAL_FINGERS "
		for i,v in ipairs(TCHORD.ideal_fingers) do
			if v then
				display = "f"..(i-1)..":"
				for j,w in ipairs(v) do
					display = display ..w.."("..TCHORD.get_pos(w)..") "
				end
				log:print(display)
			end
		end
	end,
	
	display_correct_leaves = function() 
		local display = "IDEAL_LEAVES "
		for i,v in ipairs(TCHORD.ideal_leaves) do
			display = display.."l"..i..":" ..v.."("..TCHORD.get_pos(v)..") "
		end
		log:print(display)
	end,
	
	display_correct_pred = function()
		log:print("IDEAL_PREDECESSOR "..TCHORD.ideal_predecessor.."("..TCHORD.get_pos(TCHORD.ideal_predecessor)..")")
	end,
	
-------------------------------------------------------------------------------
-- utilities
-------------------------------------------------------------------------------
	get_pos = function(node)
		local id
		if type(node) == "table" then id = node.id else id = node end
		return id%((2^TCHORD.t)-1)
	end,
	
	-- remove duplicates from view
	remove_dup = function(set)
		--local rd = misc.time()
		for i,v in ipairs(set) do
			local j = i+1
			while(j <= #set and #set > 0) do
				if v.id == set[j].id then
					table.remove(set,j)
				else j = j + 1
				end
			end
		end
		--log:print("TCHORD.remove_dup", misc.time()-rd)
	end,

	--keep n first elelements from t
	keep_n = function(t,n)
		for i = #t, n+1, -1 do
			table.remove(t,i)
		end
	end,

	remove_node  = function(t, node)
		if #t > 0 then 
			local j = 1
			for i = 1, #t do
				if TCHORD.same_node(t[j],node) then table.remove(t, j)
				else j = j+1 end
			end
		end
	end,
	--ranks the set of nodes from the point of view of the node with the specified id, based on their clockwise distance on the ring
	rank_clockwise = function(n, set)
		local distances = {}
		local ranked = {}
		for i,v in ipairs(set) do
			local dist = TCHORD.get_pos(v) - TCHORD.get_pos(n)  
			local d = 0
			if dist >= 0 then d = dist
			else d = dist + ((2^TCHORD.t)-1) end
			distances[#distances+1] = {distance= d, node=v}
		end
		table.sort(distances, function(a,b) return a.distance < b.distance end)
		for i,v in ipairs(distances) do
			ranked[#ranked+1] = v.node
		end
		return ranked
	end,
	
	rank_c_clockwise = function(n, set)
		local distances = {}
		local ranked = {}
		for i,v in ipairs(set) do
			local dist = TCHORD.get_pos(v) - TCHORD.get_pos(n)  
			local d = 0
			if dist < 0 then d = math.abs(dist)
			else d = (2^TCHORD.t)-1- dist end
			distances[#distances+1] = {distance= d, node=v}
		end
		table.sort(distances, function(a,b) return a.distance < b.distance end)
		for i,v in ipairs(distances) do
			ranked[#ranked+1] = v.node
		end
		return ranked
	end,
	
	select_by_age = function(set, n)
		table.sort(set, function(a,b) return a.age < b.age end)
		TCHORD.keep_n(set,n)
		return set
	end,
	
	same_node = function(n1,n2)
		local peer_first
		if n1.peer then peer_first = n1.peer else peer_first = n1 end
		local peer_second
		if n2.peer then peer_second = n2.peer else peer_second = n2 end
		return peer_first.port == peer_second.port and peer_first.ip == peer_second.ip
	end,
	
	remove_failed_node = function(node)	
		TCHORD.leaves_lock:lock()
		TCHORD.remove_node(TCHORD.leaves, node)
		TCHORD.leaves_lock:unlock()
		
		TCHORD.fingers_lock:lock()
		TCHORD.remove_node(TCHORD.fingers, node)
		TCHORD.fingers_lock:unlock()
		
		TCHORD.succ_view_lock:lock()
		TCHORD.remove_node(TCHORD.succ_view, node)
		TCHORD.succ_view_lock:unlock()
		
		TCHORD.pred_view_lock:lock()
		TCHORD.remove_node(TCHORD.pred_view, node)
		TCHORD.pred_view_lock:unlock()
		
		TCHORD.remove_node(PSS.view, node)
	end,
	
	nullify_node_age  = function(t, node)
		for i,v in ipairs(t) do
			if TCHORD.same_node(v, node) then v.age = 0 end
		end
	end,
	
	update_partner_age = function(partner)
		
		TCHORD.pred_view_lock:lock()
		TCHORD.nullify_node_age(TCHORD.pred_view, partner)
		TCHORD.pred_view_lock:unlock()
	end,
	
	extract_finger_candidates = function(set,p)
		local finger_candidates = {}
		for j = 1, TCHORD.t do        
			finger_candidates[j] = {}
			local b = (TCHORD.get_pos(p)+2^j)%2^TCHORD.t
			local a = (TCHORD.get_pos(p)+ 2^(j-1)-1)%2^TCHORD.t
			for i, v in ipairs(set) do
				local c = TCHORD.get_pos(v)
				if a <= b then 
					if c > a and c <= b then
						finger_candidates[j][#finger_candidates[j]+1] = v
					end
				else
					if (c > a and c < (2^TCHORD.t-1)) or (c <= b and c >= 0) then
						finger_candidates[j][#finger_candidates[j]+1] = v
					end
				end
			end
		end
		return finger_candidates
	end,
	
	--select the closest following node from set
	select_closest = function(p, set)
		local ranked = TCHORD.rank_clockwise(p, set)
		for _,v in ipairs(ranked) do
			if TCHORD.get_pos(v) ~= TCHORD.get_pos(p) then return v end
		end 
	end,
	
	update_age_merge = function(received,view)
		local new_entries = {}
		local matched = {}
		local is_new = true
		for i,v in ipairs(received) do
			for j,w in ipairs(view) do
				if TCHORD.same_node(w,v) then
					TCHORD.update_age (w,v)
					matched[j] = true
					is_new = false
					break
				end
			end
			if is_new then new_entries[#new_entries+1] = v end
			is_new = true
		end
		for i,v in ipairs(view) do
			if not matched[i] then
				v.age = v.age+1
			end
		end
	
		local merged = misc.merge(view, new_entries)
		return merged
	end,
	
	remove_stale_nodes = function(set)
		for i,v in ipairs(set) do
			if TCHORD.is_stale(v) then table.remove(set, i) end
		end
	end,
	
	find_stale_node = function(set)
		for i,v in ipairs(set) do
			if TCHORD.is_stale(v) then return v end
		end
	end,
	
	is_stale = function(node)
		if  node.age >= TCHORD.timeout then return true
		else return false end
	end,
	
	update_age  = function(n1,n2)
		if n1.age > n2.age then n1.age = n2.age end
	end,
		
	--turns a hash table into array
	remove_holes = function(t)
		local res = {}
		for i,v in pairs(t) do
			res[#res+1] = v
		end
		return res
	end,
	
	--flatten a two-dimensional array
	flatten = function(t)
		result = {}
		for i,v in ipairs(t) do
			for j,w in ipairs(v) do
				result[#result+1] = w
			end
		end
		return result
	end,

	
-------------------------------------------------------------------------------
-- Convergence
-------------------------------------------------------------------------------

-- sort all node id by position on the ring; returns a sorted list of id lists (ids may have the same position)
	rank_all_nodes = function(include_self)
		local result = {}
		local ids = {}
		--local ok, res = pcall(job.get_live_nodes())
		--if not ok then log:print(res) return end
		res = job.get_live_nodes()
		if not res then return end
		for i,v in ipairs(res) do
			if ((not include_self) and (not TCHORD.same_node(v, me))) or include_self then
				local hashed_index = compute_hash(tostring(v.ip) ..":"..tostring(v.port))
				ids[#ids+1] = hashed_index
			end
		end
		ids = TCHORD.rank_clockwise(me, ids)
		for i,v in ipairs(ids) do
			if #result ~= 0 then 
				if TCHORD.get_pos(v) ~= TCHORD.get_pos(result[#result][1]) then
					result[#result+1] = {}
					table.insert(result[#result], v)
				else
					table.insert(result[#result], v)
				end
			else
				result[#result+1] = {}
				table.insert(result[#result], v)
			end
		end
		return result
	end,
	
	traverse_ranked = function(ids, index)
		local first = 0
		for i,v in ipairs(ids) do
			if #v ~= 0 then first = i; break end
		end
		if not ids[first] then return end
		local min, jump  = TCHORD.get_pos(ids[first][1]), false
		local old_value
		for i = first, #ids do
			local value = TCHORD.get_pos(ids[i][1])
			if value == index then return ids[i] end
			if value < min then min = value; jump = true end
			if min <= index and value > index then return ids[i] end
			if jump and misc.between_c(index, old_value, min) then return ids[i] end
			old_value = value
			jump = false
		end
		return ids[first]
	end,

-- find ideal finger j from the sorted list of node ids 
	precompute_fingers = function(ids,j)
		local f_index = (TCHORD.get_pos(me)+2^(j-1))%2^TCHORD.t
		return TCHORD.traverse_ranked(ids,f_index)
	end,
	
	precompute_views = function()
		if TCHORD_CONVERGE then
			local ok, try, ranked = false, 0, {}
			while not ok do
				try = try+1
				if try < 2 then
					ranked = TCHORD.rank_all_nodes()
					if (not ranked) or (not ranked[1]) then
						log:print("TCHORD.rank_all_nodes(): returned nil  => try again")
						events.sleep(1)
					else ok = true end
				else log:print("TCHORD.rank_all_nodes(): returned nil  => cannot precompute ideal views") return false end
			end
			--local out = "all_alive_nodes: "
			--for i,v in ipairs(ranked) do
				--out = out.." "..TCHORD.get_pos(v[1])
			--end
			--log:print(out)
			local flat_ranked = TCHORD.flatten(ranked)
			for i = 1, TCHORD.l do
				TCHORD.ideal_leaves[i] = flat_ranked[i]
			end
			TCHORD.ideal_predecessor = flat_ranked[#flat_ranked]
			for i = 1, TCHORD.t do
				TCHORD.ideal_fingers[i] = TCHORD.precompute_fingers(ranked, i)
			end
			--TCHORD.display_correct_fingers()
			TCHORD.display_correct_leaves()
			--TCHORD.display_correct_pred()
			return true
		end
	end,	
		
	check_convergence = function(c,thread)
		if TCHORD_CONVERGE then
			local leaves_entries = 0
			local fingers_entries = 0
			local pred_entries = 0
			TCHORD.leaves_lock:lock()
			local match = false
			for _,v in ipairs(TCHORD.ideal_leaves) do
				for j = 1, TCHORD.l do
					if TCHORD.leaves[j] and TCHORD.get_pos(TCHORD.leaves[j]) == TCHORD.get_pos(v)then
						match  = true
						break
					end
				end
				if match then leaves_entries = leaves_entries + 1 end
				match = false
			end
			TCHORD.leaves_lock:unlock()
			
			TCHORD.pred_lock:lock()
			if TCHORD.get_pos(TCHORD.ideal_predecessor) == TCHORD.get_pos(TCHORD.predecessor) then pred_entries = 100 end
			TCHORD.pred_lock:unlock()
			
			TCHORD.fingers_lock:lock()
			local match = false
			for _,v in ipairs(TCHORD.ideal_fingers) do
				for _,w in pairs(TCHORD.fingers) do
					if TCHORD.get_pos(w) == TCHORD.get_pos(v[1]) then
						match = true
						break
					end
				end
				if match then fingers_entries = fingers_entries + 1 end
				match = false
			end
			TCHORD.fingers_lock:unlock()	
			leaves_entries = leaves_entries/(TCHORD.l/100)
			fingers_entries = fingers_entries/(TCHORD.t/100)
			log:print(table.concat({thread.." TMAN_cycle ",c," CURRENT_VIEW_STATE ",me.id," mandatory ",leaves_entries," optional ", fingers_entries," pred ",pred_entries," bytes_sent ",bytesSent," bytes_received ",bytesReceived}))
			end
		end,

-------------------------------------------------------------------------------
-- Lookup
-------------------------------------------------------------------------------

--finding the largest finger to contact
	closest_preceding_node = function(key)
		for i = TCHORD.t, 1, -1 do
			if TCHORD.fingers[i] and misc.between_c(TCHORD.get_pos(TCHORD.fingers[i]), TCHORD.get_pos(me) , TCHORD.get_pos(key)) then 
				return TCHORD.fingers[i].peer
			end
		end
		return job.me
	end,
	
	callback = function(signal, node, hops, time)
		events.fire(signal, node, hops, time)
	end,
	
	select_succ = function()
		for i = 1, TCHORD.l do
			if TCHORD.get_pos(me)~=TCHORD.leaves[i] then return TCHORD.leaves[i] end
		end
	end,
	
	recursive_find = function(m, signal, key)
		events.thread(function()
	--if this is the destination, call back to the source node and send the number of hops
			if TCHORD.get_pos(me) == TCHORD.get_pos(key) then
				rpc.call(m.origin, {'TCHORD.callback', signal, succ, m.hops, m.time})
			end
			local succ = TCHORD.select_succ()
			if not succ then log:print("recursive_find: succ undef") return end
			--log:print("recursive_find, succ", succ.id, TCHORD.get_pos(succ), "key", TCHORD.get_pos(key))
			if misc.between_c(TCHORD.get_pos(key), TCHORD.get_pos(me), TCHORD.get_pos(succ))
					or TCHORD.get_pos(key) == TCHORD.get_pos(succ) then
					rpc.call(m.origin, {'TCHORD.callback', signal, succ, m.hops, m.time})
			else --not the destination yet
				local next_node = TCHORD.closest_preceding_node(key)	
				m.hops = m.hops+1
				rpc.call(next_node, {'TCHORD.recursive_find', m, signal, key})
			end
		end)
	end,
	
	find = function(signal, key)
		--this is the source node
		local time_start = misc.time()
		local m = {origin = job.me, hops = 0, time = tostring(time_start)}
		-- i am the destination
		if TCHORD.get_pos(me) == TCHORD.get_pos(key) then return me, m.hops, m.time end
		--the first node to contact is the largest finger whose id is smaller than the key
		local first_node = TCHORD.closest_preceding_node(key)
		if TCHORD.same_node(first_node,job.me) then
			local succ = TCHORD.select_succ()
			if not succ then log:print("recursive_find: succ undef") return end
			if misc.between_c(TCHORD.get_pos(key), TCHORD.get_pos(me), TCHORD.get_pos(succ)) or
				TCHORD.get_pos(key) == TCHORD.get_pos(succ) then
				return true, succ, m.hops, m.time
			else
				m.hops = m.hops+1
				rpc.call(succ.peer, {'TCHORD.recursive_find', m, signal, key})
				return events.wait(signal, 5)
			end
		end
		m.hops = m.hops+1
		rpc.call(first_node, {'TCHORD.recursive_find', m, signal, key})
		return events.wait(signal, 5)
	end,
	
	lookup = function(signal, key)
		log:print("LOOKUP_START ".. key.."("..TCHORD.get_pos(key) ..")")
		local ok, dest, hops, time_start = TCHORD.find(signal, key)
		local time_end = misc.time()
		if not ok then log:print("LOOKUP ".. key.." FAILED") return end
		local time_elapsed = time_end-tonumber(time_start)
		local msg="LOOKUP_END "..key.."("..TCHORD.get_pos(key) ..") KEY_OWNER "..dest.id.."("..TCHORD.get_pos(dest)..") HOPS "..hops.. " DELAY "..time_elapsed
		log:print(msg)
	end,	

	precompute_resp_nodes = function(keys)
			local ids = TCHORD.rank_all_nodes(true)
			--for i,v in ipairs(ids) do
				--log:print(i, TCHORD.get_pos(v[1]))
			--end
			for _,k in ipairs(keys) do
				local index = TCHORD.get_pos(k)
				TCHORD.responsible[k] = TCHORD.traverse_ranked(ids,index)
				--local out = k.."("..TCHORD.get_pos(k).."): "
				--for i,v in ipairs(TCHORD.responsible[k]) do
				--	out = out..v.."("..TCHORD.get_pos(v)..") "
				--end
				--log:print("Responsible nodes", out)
			end
		end,

	check_correctness = function(key, node)
		if not TCHORD.responsible[key] then return "CHECK_FAILED "
		else 
			for i, v in ipairs(TCHORD.responsible[key]) do
				if TCHORD.get_pos(v) == TCHORD.get_pos(node) then return "CORRECT_FOUND " end
			end
			return "CORRECT_NOT_FOUND "
		end		
	end,


-------------------------------------------------------------------------------
-- T-Man
-------------------------------------------------------------------------------
 
 --initialise given view from PSS view
	init = function(size)		
		local buffer = misc.dup(PSS.view)
		TCHORD.remove_dup(buffer)
		TCHORD.remove_node(buffer,me)
		TCHORD.keep_n(buffer,size)
		return buffer
	end,
	
	init_all_views = function()
		if #PSS.view > 1 then
			TCHORD.predecessor = PSS.pss_getPeer()
			TCHORD.leaves = TCHORD.init(TCHORD.l)
			for i = 1, TCHORD.t do 
				TCHORD.fingers[i] = PSS.pss_getPeer()
			end
			TCHORD.succ_view = TCHORD.init(TCHORD.s)
			TCHORD.pred_view = TCHORD.init(TCHORD.s)
			TCHORD.view_init = true
			TCHORD.debug(TCHORD.cycle_succ)
			TCHORD.check_convergence(TCHORD.cycle_succ, "init")
		end
	end,

--select random peer from PSS view
	select_peer_pss = function()
		if #PSS.view > 0 then
			local i 
			repeat i = math.random(#PSS.view)
			until not TCHORD.same_node(PSS.view[i], me)
			local partner = PSS.view[i]
			return partner
		end
	end,

--select random peer from the given view
	select_peer_view = function(view)
		local stale = TCHORD.find_stale_node(view)
		if stale then return stale else return misc.random_pick(view) end
	end,

	create_message = function(partner)
		PSS.view_copy_lock:lock()		
		local pss_buffer = misc.dup(PSS.view_copy)
		PSS.view_copy_lock:unlock()
		local merged =  misc.merge(TCHORD.succ_view, TCHORD.pred_view, pss_buffer)
		merged[#merged+1] = me
		TCHORD.remove_dup(merged)
		TCHORD.remove_node(merged, partner)
		return TCHORD.select_by_age(merged, TCHORD.message_size)
	end,

	update_leaf_set = function(received)
		--local ul = misc.time()
		local buffer =  misc.merge(PSS.view,TCHORD.succ_view)
		TCHORD.remove_node(buffer,me)
		TCHORD.leaves_lock:lock()
		TCHORD.leaves = misc.merge(TCHORD.leaves, buffer)
		TCHORD.remove_dup(TCHORD.leaves)
		if received then
			TCHORD.leaves = TCHORD.update_age_merge(received,TCHORD.leaves)
		end
		TCHORD.leaves = TCHORD.rank_clockwise(me,TCHORD.leaves)
		TCHORD.keep_n(TCHORD.leaves, TCHORD.l)
		TCHORD.leaves_lock:unlock()
		--log:print("TCHORD.update_leaf_set", misc.time() - ul)
	end,

	
	update_routing_table = function(received)
		local buffer = misc.merge(PSS.view,TCHORD.succ_view,TCHORD.pred_view, TCHORD.remove_holes(TCHORD.fingers))
		TCHORD.remove_dup(buffer)
		TCHORD.remove_node(buffer,me)
		if received then buffer = TCHORD.update_age_merge(received, buffer) end
		local finger_candidates = TCHORD.extract_finger_candidates(buffer,me)
		TCHORD.fingers_lock:lock()
		for i,v in ipairs(finger_candidates) do
			if #v > 0 then TCHORD.fingers[i] = TCHORD.select_closest(me, v) end
		end
		TCHORD.fingers_lock:unlock()
	end,
	
	update_pred = function(received)
		local buffer = misc.merge(PSS.view,TCHORD.pred_view, {TCHORD.predecessor})
		if received then buffer = TCHORD.update_age_merge(received, buffer) end
		TCHORD.remove_node(buffer,me)
		buffer = TCHORD.rank_c_clockwise(me,buffer)
		TCHORD.pred_lock:lock()		
		TCHORD.predecessor = buffer[1]
		TCHORD.pred_lock:unlock()
	end,
	
	merge_view_pred = function(received)
		TCHORD.pred_view_lock:lock()
		TCHORD.pred_view =TCHORD.update_age_merge(received, TCHORD.pred_view)
		TCHORD.remove_dup(TCHORD.pred_view)
		TCHORD.pred_view = TCHORD.rank_c_clockwise(me, TCHORD.pred_view)
		TCHORD.keep_n(TCHORD.pred_view, TCHORD.s)
		TCHORD.pred_view_lock:unlock()
	end,
	
	merge_view_succ = function(received)
		TCHORD.succ_view_lock:lock()
		TCHORD.succ_view = TCHORD.update_age_merge(received, TCHORD.succ_view)
		TCHORD.remove_dup(TCHORD.succ_view)
		TCHORD.succ_view = TCHORD.rank_clockwise(me, TCHORD.succ_view)
		TCHORD.keep_n(TCHORD.succ_view, TCHORD.s)
		TCHORD.succ_view_lock:unlock()
	end,


	passive_thread_pred = function(received,sender)
		if not TCHORD.view_init then return false end
		local buffer = TCHORD.create_message(sender)
		TCHORD.update_pred(received)
		TCHORD.update_routing_table(received)
		TCHORD.merge_view_pred(received)
		TCHORD.update_partner_age(sender)
		return buffer
	end,
	
	passive_thread_succ = function(received,sender)
		if not TCHORD.view_init then return false end
		local buffer = TCHORD.create_message(sender)
		TCHORD.update_leaf_set(received)
		TCHORD.update_routing_table(received)
		TCHORD.merge_view_succ(received)
		TCHORD.update_partner_age(sender)
		return buffer
	end,
	
	select_partner = function(partner_select_code, loc_cycle, view)
		if partner_select_code == 0 then --alternating
			if loc_cycle <= 2 then return TCHORD.select_peer_pss()
			else 
				if loc_cycle%2==0 then return TCHORD.select_peer_pss() else return TCHORD.select_peer_view(view) end
			end
		elseif partner_select_code == 1 then --only pss
			return TCHORD.select_peer_pss()
		elseif partner_select_code == 2 then --only view
			return TCHORD.select_peer_view(view)
		end	
	end,

	active_thread_pred = function()
		TCHORD.cycle_pred_lock:lock()
		local loc_cycle = TCHORD.cycle_pred+1
		TCHORD.cycle_pred = TCHORD.cycle_pred+1
		TCHORD.cycle_pred_lock:unlock()
		local partner = TCHORD.select_partner(TCHORD_PARTNER_SELECT, loc_cycle, TCHORD.pred_view)
		if not partner then log:print("TCHORD.active_thread_pred: no partner selected") return end
		local buffer = TCHORD.create_message(partner)		
		local try = 0
		local ok, res = rpc.acall(partner.peer,{'TCHORD.passive_thread_pred', buffer,me})
		while not ok do
			try = try + 1
			if try <= 2 then
				log:print("TCHORD.active_thread_pred: no response from:"..partner.id.. ": "..tostring(res).." => try again")
				ok, res = rpc.acall(partner.peer,{'TCHORD.passive_thread_pred',buffer,me})
			else
				log:print("TCHORD.active_thread_pred: no response from:"..partner.id..": "..tostring(res).."  => removing it from view")
				TCHORD.remove_failed_node(partner)
				TCHORD.update_leaf_set()
				TCHORD.update_routing_table()
				break
			end
		end
		if ok then
			local received = res[1]
			TCHORD.update_partner_age(partner)
			if received==false then
					log:print("active_thread_pred: received false from "..partner.id)
			else
				TCHORD.update_pred(received)
				TCHORD.update_routing_table(received)		
				TCHORD.merge_view_pred(received)
				resource_stats()
				TCHORD.precompute_views()
				TCHORD.check_convergence(loc_cycle,'active_thread_pred')
				--TCHORD.debug(loc_cycle)
			end
		end
	end,
	
	active_thread_succ = function()
		TCHORD.cycle_succ_lock:lock()
		local loc_cycle = TCHORD.cycle_succ+1
		TCHORD.cycle_succ = TCHORD.cycle_succ+1
		TCHORD.cycle_succ_lock:unlock()
		local partner = TCHORD.select_partner(TCHORD_PARTNER_SELECT, loc_cycle, TCHORD.succ_view)		
		if not partner then log:print("TCHORD.active_thread_pred: no partner selected") return end
		local buffer = TCHORD.create_message(partner)	
		local try = 0
		local ok, res = rpc.acall(partner.peer, {'TCHORD.passive_thread_succ',buffer,me})
		while not ok do
			try = try + 1
			if try <= 2 then
				log:print("TCHORD.active_thread_succ: no response from:"..partner.id.. ": "..tostring(res).." => try again")
				ok, res = rpc.acall(partner.peer,{'TCHORD.passive_thread_succ',buffer,me})
			else
				log:print("TCHORD.active_thread_succ: no response from:"..partner.id..": "..tostring(res).."  => removing it from view")
				TCHORD.remove_failed_node(partner)
				TCHORD.update_leaf_set()
				TCHORD.update_routing_table()
				break
			end
		end
		if ok then
			local received = res[1]
			TCHORD.update_partner_age(partner)	
			if received==false then
					log:print("active_thread_succ: received false from "..partner.id)
			else
				TCHORD.update_leaf_set(received)
				TCHORD.update_routing_table(received)
				TCHORD.merge_view_succ(received)
				resource_stats()
				TCHORD.precompute_views()
				TCHORD.check_convergence(loc_cycle,'active_thread_succ')
				--TCHORD.debug(loc_cycle)
			end
		end
	end,
}
	
-------------------------------------------------------------------------------
-- Main loop
-------------------------------------------------------------------------------


function resource_stats()
	local ts,tr = socket.stats()
	local tot_KB_sent=misc.bitcalc(ts).kilobytes
	local tot_KB_recv=misc.bitcalc(tr).kilobytes
	bytesSent = tot_KB_sent
	bytesReceived = tot_KB_recv
end

function terminator()
  events.sleep(max_time)
  os.exit()
end

query_counter = 0
function lookup_test()
	query_counter = query_counter+1
	local key = compute_hash(tostring(math.random()))+me.id
	TCHORD.lookup(query_counter..key,key)
end


function main()
-- this thread will be in charge of killing the node after max_time seconds
	if not TCHORD_CHURN then events.thread(terminator) end
	log:print("UP: "..job.me.ip..":"..job.me.port)
	log:print(table.concat({"ME: ", me.id, " (", TCHORD.get_pos(me), ") "..job.position}))
	bytesSent = 0
	bytesReceived = 0
	
-- init random number generator
	math.randomseed(job.position*os.time())
	
-- wait for all nodes to start up (conservative)
	events.sleep(1)
	
-- desynchronize the nodes
	local desync_wait = (PSS_SHUFFLE_PERIOD * math.random())
	log:print("waiting for "..desync_wait.." to desynchronize")
	events.sleep(desync_wait)
	
-- initialize PSS
	PSS.pss_init()
	events.sleep(2)
	PSS_thread = events.periodic(PSS_SHUFFLE_PERIOD, PSS.pss_active_thread) 
	events.sleep(100)
	
--starting TMAN
	if TCHORD.precompute_views() then
		TCHORD.init_all_views()
	else log:print("TCHORD.precompute_views(): failed to precompute ideal views") end
	
	if TCHORD.view_init then -- init failed?
		
		log:print("VIEW_CONSTRUCTION_START_TIME", misc.time())
		TCHORD_thread = events.periodic(GOSSIP_TIME, {TCHORD.active_thread_succ,TCHORD.active_thread_pred})
		if TCHORD_CHURN then 
			lookup_thread = events.periodic(3, {lookup_test})
		end
		
		if TCHORD_LOOKUP then
			events.sleep(300)
			events.kill({TCHORD_thread, PSS_thread})
			events.sleep(60)
			--generate keys
			for i = 1, 50 do
				TCHORD.keys[#TCHORD.keys+1] = compute_hash(tostring(math.random()))+me.id
			end
			--precompute responsible
			TCHORD.precompute_resp_nodes(TCHORD.keys)
			events.sleep(10)
	
			--launch lookups
			for i,v in ipairs(TCHORD.keys) do
				events.thread(function() TCHORD.lookup(i..v,v) end)
				events.sleep(1)
			end	
		end 
			
	else log:print("main: could not launch TMAN due to uninitialised views") end
		
end  

events.thread(main)  
events.loop()
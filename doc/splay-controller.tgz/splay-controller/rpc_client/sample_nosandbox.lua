-- BASE libraries (threads, events, sockets, ...)
require"splay.base"
function main()
        log:print(os.execute('uname -a'))
end
events.thread(main)
events.loop()


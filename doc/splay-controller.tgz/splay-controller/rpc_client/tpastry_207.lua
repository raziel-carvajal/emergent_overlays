-------------------------------------------------------------------------------
-- modules
-------------------------------------------------------------------------------

require"splay.base"
rpc = require"splay.rpc"
rpc.l_o.level=1
misc = require "splay.misc"
crypto = require "crypto"

-- addition to allow local run
PARAMS={}
local cmd_line_args=nil
if not job then --outside the sandbox
	if #arg < 2 then  
		print("lua ", arg[0], " my_position nb_nodes")  
		os.exit()  
	else  		
		local pos, total = tonumber(arg[1]), tonumber(arg[2])  
		local utils = require("splay.utils")
		job = utils.generate_job(pos, total, 20001) 
		cmd_line_args=arg[3]	
	end
end

if arg~=nil then
	if cmd_line_args==nil then cmd_line_args=arg[1] end
	if cmd_line_args~=nil and cmd_line_args~="" then
		print("ARGS: ",cmd_line_args)	
		for _,v in pairs(misc.split(cmd_line_args,":")) do
			local t=misc.split(v,"=")
			PARAMS[t[1]]=t[2]
		end
	end
end


rpc.server(job.me.port)

-------------------------------------------------------------------------------
-- parameters
-------------------------------------------------------------------------------

--PSS params
PSS_VIEW_SIZE =tonumber(PARAMS["PSS_VIEW_SIZE"]) or 6
PSS_SHUFFLE_SIZE =  tonumber(PARAMS["PSS_SHUFFLE_SIZE"]) or math.floor(PSS_VIEW_SIZE / 2 + 0.5)
PSS_SHUFFLE_PERIOD = tonumber(PARAMS["PSS_SHUFFLE_PERIOD"]) or 10


max_time = 2600
g_timeout = 60
actions = 0
bytesSent = 0
bytesReceived = 0

--T-Pastry params
GOSSIP_TIME = tonumber(PARAMS["GOSSIP_TIME"]) or 5
TPASTRY_HB_TIMEOUT = tonumber(PARAMS["TPASTRY_HB_TIMEOUT"]) or 10
TPASTRY_CONVERGE = PARAMS["PASTRY_CONVERGE"] or true
TPASTRY_LOOKUP = tonumber(PARAMS["TPASTRY_LOOKUP"]) or false
TPASTRY_RANDOM = tonumber(PARAMS["TPASTRY_RANDOM"]) or 6
TPASTRY_VIEW_SIZE = tonumber(PARAMS["TPASTRY_VIEW_SIZE"]) or 6
TPASTRY_MESSAGE_SIZE = tonumber(PARAMS["TPASTRY_MESSAGE_SIZE"]) or 10
PARTNER_SELECT = tonumber(PARAMS["PARTNER_SELECT"]) or 0
leaf_size = tonumber(PARAMS["TPASTRY_LEAF_SIZE"]) or 2

b, bits = 4, 128
key_size = math.log(2^bits)/ math.log(2^b)
if key_size < 2^b then
	print("Key size must be greater or equal than base")
	os.exit()
end
if b ~= 4 then
	print("b must be 4, because base 16 (hexadecimal) is needed in one function.")
	os.exit()
end

-------------------------------------------------------------------------------
-- current node
-------------------------------------------------------------------------------

me = {}
me.peer = job.me
me.age = 0
function compute_id(o) return string.sub(crypto.evp.new("sha1"):digest(o), 1, bits / 4) end
me.id = compute_id(job.me.ip..job.me.port)
log:print("ME: "..me.id.." "..job.me.ip..":"..job.me.port)



-- ############################################################################
-- 	Peer Sampling Service
-- ############################################################################

PSS = {

	view = {},
	view_copy = {},
	c = PSS_VIEW_SIZE,
	exch = PSS_SHUFFLE_SIZE,
	H = 1,
	S = math.floor(PSS_VIEW_SIZE/ 2 + 0.5) - 1,
	SEL = "rand", -- could also be "tail"
	view_copy_lock = events.lock(),
	
	-- utilities
	print_table = function(t)
		print("[ (size "..#t..")")
		for i=1,#t do
			print("  "..i.." : ".."["..t[i].peer.ip..":"..t[i].peer.port.."] - age: "..t[i].age.." - id: "..t[i].id)
		end
		print("]")
	end,
	
	set_of_peers_to_string = function(v)
		ret = ""; for i=1,#v do	ret = ret..v[i].id.." "	end
		return ret
	end,
	
	print_set_of_peers = function(v,message)	
		if message then log:print(message) end
		log:print(PSS.set_of_peers_to_string(v))
	end,
	
	print_view = function(message)
		if message then log:print(message) end
		log:print("PSS VIEW_CONTENT "..job.position.." "..PSS.set_of_peers_to_string(PSS.view))
	end,
	
	-- peer sampling functions
	
	pss_selectPartner= function()
		if #PSS.view > 0 then
			if PSS.SEL == "rand" then return math.random(#PSS.view) end
			if PSS.SEL == "tail" then
				local ret_ind = -1 ; local ret_age = -1
				for i,p in pairs(PSS.view) do
					if (p.age > ret_age) then ret_ind = i;ret_age=p.age end
				end
				assert (not (ret_ind == -1))
				return ret_ind
			end
		else return false end
	end,
	
	same_peer_but_different_ages = function(a,b)
		return a.peer.ip == b.peer.ip and a.peer.port == b.peer.port
	end,

	same_peer = function(a,b)
		return PSS.same_peer_but_different_ages(a,b) and a.age == b.age
	end,
	
	pss_selectToSend = function()

		-- create a new return buffer
		local toSend = {}
		-- append the local node view age 0
		table.insert(toSend,{peer={ip=job.me.ip,port=job.me.port},age=0,id=me.id})
		if #PSS.view > 0 then 
			-- shuffle view
			PSS.view = misc.shuffle(PSS.view)
			-- move oldest H items to the end of the view
			--- 1. copy the view
			local tmp_view = misc.dup(PSS.view)
			--- 2. sort the items based on the age
			table.sort(tmp_view,function(a,b) return a.age < b.age end)
			--- 3. get the H largest aged elements from the tmp_view, remove them from the view 
			---    (we assume there are no duplicates in the view at this point!)
			---    and put them at the end of the view
			for i=(#tmp_view-PSS.H+1),#tmp_view do
				local ind = -1
				for j=1,#PSS.view do
					if PSS.same_peer(tmp_view[i],PSS.view[j]) then ind=j; break end
				end
				assert (not (ind == -1))
				elem = table.remove(PSS.view,ind)
				PSS.view[#PSS.view+1] = elem
			end
	
			-- append the first exch-1 elements of view to toSend
			for i=1,(PSS.exch-1) do
				toSend[#toSend+1]=PSS.view[i]
			end
		end
		return toSend
	end,
	
	pss_selectToKeep = function(received)
		local selectToKeepStart= misc.time()	
		-- concatenate the view and the received set of view items
		for j=1,#received do PSS.view[#PSS.view+1] = received[j] end
		
		-- remove duplicates from view
		-- note that we can't rely on sorting the table as we need its order later
		local i = 1	
		while i < #PSS.view-1 do
			for j=i+1,#PSS.view do
				if PSS.same_peer_but_different_ages(PSS.view[i],PSS.view[j]) then
					-- delete the oldest
					if PSS.view[i].age < PSS.view[j].age then 
						table.remove(PSS.view,j)
					else
						table.remove(PSS.view,i)
					end
					i = i - 1 -- we need to retest for i in case there is one more duplicate
					break
				end
			end
			i = i + 1
		end
	
		-- remove the min(H,#view-c) oldest items from view
		local o = math.min(PSS.H,#PSS.view-PSS.c)
		while o > 0 do
			-- brute force -- remove the oldest
			local oldest_index = -1
			local oldest_age = -1
			for i=1,#PSS.view do 
				if oldest_age < PSS.view[i].age then
					oldest_age = PSS.view[i].age
					oldest_index = i
				end
			end
			assert (not (oldest_index == -1))
			table.remove(PSS.view,oldest_index)
			o = o - 1
		end
		
		-- remove the min(S,#view-c) head items from view
		o = math.min(PSS.S,#PSS.view-PSS.c)
		while o > 0 do
			table.remove(PSS.view,1) -- not optimal
			o = o - 1
		end
		
		-- in the case there still are too many peers in the view, remove at random
		while #PSS.view > PSS.c do table.remove(PSS.view,math.random(#PSS.view)) end
	
		assert (#PSS.view <= PSS.c)
		--log:print("PSS_SELECT_TO_KEEP ", ( misc.time() - selectToKeepStart ) )		
	end,
	
	ongoing_at_rpc=false,
	
	is_init = false,
	
	pss_passive_thread = function(from,buffer)
		if PSS.ongoing_at_rpc or not PSS.is_init then
			return false
		end
		
		--PSS.print_view("passive_thread ("..job.position.."): entering")
		--PSS.print_set_of_peers(buffer,"passive_thread ("..job.position.."): received from "..from)
		
		local ret = PSS.pss_selectToSend()
		PSS.pss_selectToKeep(buffer)
		--PSS.print_view("passive_thread ("..job.position.."): after selectToKeep")
		return ret
	end,
	
	pss_send_at_rpc = function(peer,pos,buf)
		local ok, r = rpc.acall(peer,{"PSS.pss_passive_thread", pos, buf},PSS_SHUFFLE_PERIOD/2)
		return ok,r
	end,
	
	pss_active_thread = function()
		PSS.ongoing_at_rpc=true
		-- select a partner
		local exchange_aborted=true
		local exchange_retry=5
		for i=1,exchange_retry do --up to 5 attemps per round, re-do in case of conflict 
			partner_ind = PSS.pss_selectPartner()
			local init_retry=0
			while not partner_ind do
				init_retry=init_retry+1
				if init_retry<=2 then
					log:print("pss_active_thread: pss view is empty, re-initialising the view")
					PSS.pss_init()
					partner_ind = PSS.pss_selectPartner()
				else break end
			end
			if not partner_ind then
				log:print("pss_active_thread: pss view is empty, no partner can be selected")
				return
			end
			partner = PSS.view[partner_ind]
			-- remove the partner from the view
			table.remove(PSS.view,partner_ind)
			-- select what to send to the partner
			buffer = PSS.pss_selectToSend()
			--PSS.print_set_of_peers(buffer,"active_thread ("..job.position.."): sending to "..partner.id)

			-- send to the partner
			--local rpcStart=misc.time()
			local ok, r = PSS.pss_send_at_rpc(partner.peer,job.position, buffer) -- rpc.acall(partner.peer,{"PSS.pss_passive_thread", job.position, buffer},PSS_SHUFFLE_PERIOD/2)
			--log:print("PSS.pss_passive_thread.RPC ",  misc.time() - rpcStart  )
			if ok then
				-- select what to keep etc.
				local received = r[1]
				if received==false then
					log:print("PSS received false due to ongoing RPC or yet uninitialized view, will try again in a short while")
					events.sleep(math.random())	
					--the call was aborted due to pending RPC at peer's node
				else
					exchange_aborted=false 
					--PSS.print_set_of_peers(received,"active_thread ("..job.position.."): received from "..partner.id)
					PSS.pss_selectToKeep(received)
					--PSS.print_view("pss_active_thread ("..job.position.."): after selectToKeep")
				end
			else
				-- peer not replying? remove it from view!
				log:print("on peer ("..job.position..") peer "..partner.id.." did not respond -- removing it from the view")
				log:warning("PSS.pss_passive_thread RPC error:", r)
				table.remove(PSS.view,partner_ind)
			end		
			if exchange_aborted==false then break end
		end
		for _,v in ipairs(PSS.view) do
				v.age = v.age+1
		end
		PSS.view_copy_lock:lock()
		local viewCopyLock = misc.time()
		PSS.view_copy = misc.dup(PSS.view)
		--log:print("PSS_VIEW_COPY_LOCK_HELD ", ( misc.time() - viewCopyLock ) )
		PSS.view_copy_lock:unlock()
		-- now, allow to have an incoming passive thread request
		PSS.ongoing_at_rpc=false
	end,
	
	-- API
	pss_getPeer = function()
		PSS.view_copy_lock:lock()
		local getPeerLockHeldStart = misc.time()
		
		local peer = PSS.view_copy[math.random(#PSS.view_copy)] 

		--log:print("PSS_GET_PEER_LOCK_HELD_VIEW_COPY ", ( misc.time() - getPeerLockHeldStart ) )
		PSS.view_copy_lock:unlock()

		return peer
	end,

	pss_init = function()
		-- ideally, would perform a random walk on an existing overlay
		-- but here we emerge from the void, so let's use the Splay provided peers.
		-- Ages are taken randomly in [0..c] but could be 0 as well.
		local indexes = {}
		for i=1,#job.get_live_nodes() do indexes[#indexes+1]=i end
		table.remove(indexes,job.position) --remove myself
		local selected_indexes = misc.random_pick(indexes,math.min(PSS.c,#indexes))	
		for _,v in pairs(selected_indexes) do
				local a_peer = job.get_live_nodes()[v]
				local hashed_index = compute_id(a_peer.ip..a_peer.port)
		 		PSS.view[#PSS.view+1] = 
				{peer=a_peer,age=math.random(PSS.c),id=hashed_index}
		end
		PSS.view_copy = misc.dup(PSS.view)
		assert (#PSS.view == math.min(PSS.c,#indexes))
		--PSS.print_view("initial view")
		PSS.is_init = true
	end,

	
	log_view = function()
		-- called once to log the view
		events.sleep(10.5*PSS_SHUFFLE_PERIOD)
		log:print("VIEW_CONTENT "..job.position.." "..PSS.set_of_peers_to_string(PSS.view))
	end,

}

-- ############################################################################
-- 	T-PASTRY
-- ############################################################################

TPASTRY = {
	r = TPASTRY_RANDOM,
	s = TPASTRY_VIEW_SIZE,
	timeout = TPASTRY_HB_TIMEOUT,
	m = TPASTRY_MESSAGE_SIZE,
	leaves_decreasing = {},
	leaves_increasing = {},
	routing_table = {},
	succ_view = {},
	pred_view = {},
	pred_view_lock = events.lock(),
	succ_view_lock = events.lock(),
	in_leaves_lock = events.lock(),
	de_leaves_lock = events.lock(),
	rt_lock = events.lock(),
	ideal_leaves_increasing = {},
	ideal_leaves_decreasing = {},
	ideal_routing_table = {},
	opt_entries = 0,
	cycle_succ = 0,
	cycle_pred = 0,
	cycle_pred_lock = events.lock(),
	cycle_succ_lock = events.lock(),
	responsible = {},
	view_init = false,
	lookup_token = false,
	keys = {},
	
-------------------------------------------------------------------------------
-- debug
-------------------------------------------------------------------------------
	
	display_view = function(v, which)
 		local display = table.concat({which," CONTENT for nodeID ",TPASTRY.num(me),": \t"})
		for i,w in ipairs(v) do
			display = table.concat({display," ", w.id})
		end
		log:print(display)
	end,
	
	display_route_table = function()
		local out = ""
		for i = 0, key_size / 4 do
			local str = table.concat({"",i,": "})
			for c = 0, 2^b - 1 do
				if TPASTRY.routing_table[i][c] then
					str = table.concat({str," ",TPASTRY.routing_table[i][c].id})
				else
					str = table.concat({str," -"})
				end
			end
			out = table.concat({out,str,"\n"})
		end
		return out
	end,

	display_leaf = function(l_d, l_i)
		local out = "DECREASING "
		for i = #l_d, 1, -1 do
			if l_d[i] then
				local value
				if l_d[i].id then value = l_d[i].id else value = l_d[i] end
				out = table.concat({out," (-)",value})
			end
		end
		out = table.concat({out," [",me.id,"] INCREASING "})
		for i = 1, #l_i do
			if l_i[i] then
				local value
				if l_i[i].id then value = l_i[i].id else value = l_i[i] end
				out = table.concat({out," (+)",value})
			end
		end
		return out
	end,

	debug = function(c)
		log:print(table.concat({"TPASTRY cycle ",c, ":",TPASTRY.display_leaf(TPASTRY.leaves_decreasing, TPASTRY.leaves_increasing)}))
		--log:print(TPASTRY.display_route_table()) 

	end,

	
-------------------------------------------------------------------------------
-- utilities
-------------------------------------------------------------------------------

	num = function(k)
		if k.id then return tonumber("0x"..k.id) else return tonumber("0x"..k) end
	end,

	diff_clock = function(key1, key2)
		local k1, k2 = TPASTRY.num(key1), TPASTRY.num(key2)
		if k1 < k2 then return k2 - k1 else return 2^bits - k1 + k2 end
	end,

	diff_c_clock = function(key1, key2)
		local k1, k2 = TPASTRY.num(key1), TPASTRY.num(key2)
		if k1 < k2 then return 2^bits - k2 + k1 else return k1 - k2 end
	end,
	
	diff = function(key1, key2)
		local k1, k2, a, b = TPASTRY.num(key1), TPASTRY.num(key2)
		if k1 < k2 then a, b = k2, k1 else a, b = k1, k2 end
		return math.min(a - b, 2^bits - a + b)
	end,
	
	shared_prefix_length = function(a, b)
		for i = 1, key_size do
			if string.sub(a, i, i) ~= string.sub(b, i, i) then return i - 1 end
		end
		return key_size
	end,

	row_col = function(key)
		local row = TPASTRY.shared_prefix_length(key, me.id)
		return row, TPASTRY.num(string.sub(key, row + 1, row + 1))
	end,

	row_col_partner = function(key,partner)
		local row = TPASTRY.shared_prefix_length(key, partner.id)
		return row, TPASTRY.num(string.sub(key, row + 1, row + 1))
	end,

	--sorts nodes according to the distance on the ring from the given node
	rank_clockwise = function(t,partner)
		table.sort(t, function (a,b) return TPASTRY.diff_clock(partner,a) < TPASTRY.diff_clock(partner,b) end)
	end,
	
	rank_c_clockwise = function(t,partner)
		table.sort(t, function (a,b) return TPASTRY.diff_c_clock(partner,a) < TPASTRY.diff_c_clock(partner,b) end)
	end,

	-- remove duplicates from view
	remove_dup = function(set)
		--local rd = misc.time()
		for i,v in ipairs(set) do
			local j = i+1
			while(j <= #set and #set > 0) do
				if v.id == set[j].id then
					table.remove(set,j)
				else j = j + 1
				end
			end
		end
		--log:print("TPASTRY.remove_dup", misc.time()-rd)
	end,

	--keep n first elelements from t
	keep_n = function(t,n)
		for i = #t, n+1, -1 do
			table.remove(t,i)
		end
	end,
	
	remove_node = function(t, node)
		local j = 1
		for i = 1, #t do
			if TPASTRY.same_node(t[j],node) then table.remove(t, j)
			else j = j+1 end
		end
	end,
	
	flatten = function(t)
		result = {}
		for i,v in ipairs(t) do
			for j,w in ipairs(v) do
				result[#result+1] = w
			end
		end
		return result
	end,
	
	same_node = function(n1,n2)
		local peer_first
		if n1.peer then peer_first = n1.peer else peer_first = n1 end
		local peer_second
		if n2.peer then peer_second = n2.peer else peer_second = n2 end
		return peer_first.port == peer_second.port and peer_first.ip == peer_second.ip
	end,
	
	remove_failed_node = function(node)
	
		TPASTRY.de_leaves_lock:lock()
		TPASTRY.remove_node(TPASTRY.leaves_decreasing, node)
		TPASTRY.de_leaves_lock:unlock()
		TPASTRY.in_leaves_lock:lock()
		TPASTRY.remove_node(TPASTRY.leaves_increasing, node)
		TPASTRY.in_leaves_lock:unlock()
		
		TPASTRY.succ_view_lock:lock()
		TPASTRY.remove_node(TPASTRY.succ_view, node)
		TPASTRY.succ_view_lock:unlock()
		
		TPASTRY.pred_view_lock:lock()
		TPASTRY.remove_node(TPASTRY.pred_view, node)
		TPASTRY.pred_view_lock:unlock()
		
		TPASTRY.rt_lock:lock()
		TPASTRY.remove_node(TPASTRY.routing_table, node)
		TPASTRY.rt_lock:unlock()
		
		TPASTRY.remove_node(PSS.view, node)
	end, 
	
	update_age_merge = function(received,view)
		TPASTRY.remove_dup(view)
		local new_entries = {}
		local matched = {}
		local is_new = true
		for i,v in ipairs(received) do
			for j,w in ipairs(view) do
				if TPASTRY.same_node(w,v) then
					TPASTRY.update_age (w,v)
					matched[j] = true
					is_new = false
					break
				end
			end
			if is_new then new_entries[#new_entries+1] = v end
			is_new = true
		end
		for i,v in ipairs(view) do
			if not matched[i] then
				v.age = v.age+1
			end
		end
		local merged = TPASTRY.merge(view, new_entries)
		return merged
	end,
	
	remove_stale_nodes = function(set)
		for i,v in ipairs(set) do
			if TPASTRY.is_stale(v) then table.remove(set, i) end
		end
	end,
	
	find_stale_node = function(set)
		for i,v in ipairs(set) do
			if TPASTRY.is_stale(v) then return v end
		end
	end,
	
	is_stale = function(node)
		if  node.age >= TPASTRY.timeout then return true
		else return false end
	end,
	
	update_age  = function(n1,n2)
		if n1.age > n2.age then n1.age = n2.age end
	end,
	
	--merge a variable length list of (flat) arrays into a single array, returns a new array without duplicates
	merge = function(...)
		local t, res = {}, {}
		for i,v in ipairs(arg) do
			for j,w in ipairs(v) do local id = w.id; t[id]= w end
		end
		for i,v in pairs(t) do res[#res+1] = v end
		return res
	end,
	
	select_by_age = function(set, n)
		table.sort(set, function(a,b) return a.age < b.age end)
		TPASTRY.keep_n(set,n)
		return set
	end,
	
-------------------------------------------------------------------------------
-- Convergence
-------------------------------------------------------------------------------
	hash_all = function()
		local ids = {}
		for i,v in ipairs(job.get_live_nodes()) do
			if not TPASTRY.same_node(v,me) then ids[#ids+1] = compute_id(v.ip..v.port) end
		end
		return ids
	end,

	precompute_leaves = function(ids)
		TPASTRY.ideal_leaves_increasing, TPASTRY.ideal_leaves_decreasing = {},{}		 
		TPASTRY.rank_clockwise(ids,me)
		for i = 1, leaf_size/2 do
			table.insert(TPASTRY.ideal_leaves_increasing, ids[i])
		end
		for i = #ids, #ids-leaf_size/2+1, -1 do
			table.insert(TPASTRY.ideal_leaves_decreasing, ids[i])
		end
		--local out = "all alive ranked "..#ids..": "
		--for i,v in ipairs(ids) do out = out.." "..v end
		--log:print(out)
		--log:print(table.concat({"IDEAL_LEAVES: ", TPASTRY.display_leaf(TPASTRY.ideal_leaves_decreasing, TPASTRY.ideal_leaves_increasing)}))
	end,
	
	precompute_routing_table = function(ids)
		TPASTRY.ideal_routing_table = {}
		local entries = 0
		for i = 0, key_size - 1 do
			TPASTRY.ideal_routing_table[i] = {}
		end
		for i,v in ipairs(ids) do
			local row, col = TPASTRY.row_col(v)
			if row and col then
				if TPASTRY.ideal_routing_table[row][col] then --column is not empty
					table.insert(TPASTRY.ideal_routing_table[row][col], v)
				else
					TPASTRY.ideal_routing_table[row][col] = {}
					table.insert(TPASTRY.ideal_routing_table[row][col], v)
					entries = entries + 1
				end
			end
		end
		return entries
	end,
	
	precompute_views = function() 
		if TPASTRY_CONVERGE then
			local ids = TPASTRY.hash_all()
			TPASTRY.precompute_leaves(ids)
			TPASTRY.opt_entries = TPASTRY.precompute_routing_table(ids)
			--log:print("COMPLETE_VIEW_STATE "..me.id.." mandatory ".. leaf_size.." optional "..TPASTRY.opt_entries)
		end
	end,
		
	check_convergence = function(c,thread)
		if TPASTRY_CONVERGE then
			local errors_rt, errors_l = 0,0
		--check prefix table
			TPASTRY.rt_lock:lock()
			for i = 0, key_size/4 do
				for j = 0, 2^b-1 do
					if not TPASTRY.routing_table[i][j] then
							if TPASTRY.ideal_routing_table[i][j] then
								errors_rt = errors_rt+1 
							end
					else --the row/col in rt is not empty
						local correct = false
						if TPASTRY.ideal_routing_table[i][j] then 				
							for k = 1, #TPASTRY.ideal_routing_table[i][j] do
								if TPASTRY.routing_table[i][j].id == TPASTRY.ideal_routing_table[i][j][k]	 then
									correct = true
									break
								end
							end
							if not correct then errors_rt = errors_rt+1 end
						end
					end
				end
			end
			TPASTRY.rt_lock:unlock()	
	
		--check leaf sets
			TPASTRY.de_leaves_lock:lock()
			for i = 1, leaf_size/2 do
				if TPASTRY.leaves_decreasing[i] then
					if TPASTRY.leaves_decreasing[i].id ~= TPASTRY.ideal_leaves_decreasing[i] then errors_l = errors_l + 1 end
				else errors_l = errors_l + 1 end
			end
			TPASTRY.de_leaves_lock:unlock()
	
			TPASTRY.in_leaves_lock:lock()
			for i = 1, leaf_size/2 do
				if TPASTRY.leaves_increasing[i] then
					if TPASTRY.leaves_increasing[i].id ~= TPASTRY.ideal_leaves_increasing[i] then errors_l = errors_l + 1 end
				else errors_l = errors_l + 1 end		 
			end
			TPASTRY.in_leaves_lock:unlock()
			local mand = (leaf_size-errors_l)/(leaf_size/100)
			local opt = (TPASTRY.opt_entries-errors_rt)/(TPASTRY.opt_entries/100)		
			log:print(table.concat({thread.." TMAN_cycle ",c," CURRENT_VIEW_STATE ",me.id," mandatory ",mand," optional ", opt," bytes_sent ",bytesSent," bytes_received ",bytesReceived}))
		end	
	end,
	
	display_ideal_rt = function()
	for i = 0, #TPASTRY.ideal_routing_table do
		print("row", i)
		for j,w in pairs(TPASTRY.ideal_routing_table[i]) do
			print ("\tcolumn", j)
			local out = ""
				for k,x in pairs(w) do 
					out = out.." "..x
				end
			print("\t\t"..out)	
		end
	end
end,


-------------------------------------------------------------------------------
-- Lookup
-------------------------------------------------------------------------------
	leaves = function()
		local L = misc.dup(TPASTRY.leaves_decreasing)
		for _, e in pairs(TPASTRY.leaves_increasing) do
			local found = false
			for _, e2 in pairs(TPASTRY.leaves_decreasing) do
				if e.id == e2.id then found = true break end
			end
			if not found then L[#L + 1] = e end
		end
		return L
	end,

-- including self in the range
	range_leaf = function(D)
		local min, max = TPASTRY.num(me), TPASTRY.num(me)
		if #TPASTRY.leaves_decreasing > 0 then min = TPASTRY.num(TPASTRY.leaves_decreasing[#TPASTRY.leaves_decreasing]) end
		if #TPASTRY.leaves_increasing > 0 then max = TPASTRY.num(TPASTRY.leaves_increasing[#TPASTRY.leaves_increasing]) end
		return misc.between_c(TPASTRY.num(D), min - 1, max + 1)
	end,

	nearest = function(D, nodes)
		local d, j = math.huge, nil
			for i, n in pairs(nodes) do
			if TPASTRY.diff(D, n) < d then
				d = TPASTRY.diff(D, n)
				j = i
			end
		end
		return nodes[j]
	end,

	try_route = function(msg, key, T)
		msg.count_hops = msg.count_hops+1
		local ok, n = rpc.acall(T.peer, {'TPASTRY.route', msg, key}, g_timeout)
		if ok then
			if n[1] then
				return unpack(n)
			else
				return nil
			end
		else 
			log:print("cannot route through "..T.id)
		end
	end,

	route = function(msg, key, no_count_action) -- Pastry API
		if not no_count_action then actions = actions + 1 end
		if not msg.time then msg.time = tostring(misc.time()) end
		if not msg.count_hops then msg.count_hops = 0 end
		if msg.count_hops > 15 then
			log:warn("Problem routing "..key.." max hops reached")
			return nil, "routing problem max hops reached: "..key
		end

		if msg.typ == "#test#" then
			if not msg.count then msg.count = 0 else msg.count = msg.count + 1 end
			if not msg.trace then msg.trace = "" end
			if not msg.hops then msg.hops = {me} else table.insert(msg.hops, me) end
		end

		if key ~= me.id then
			if TPASTRY.range_leaf(key) then
				local n = TPASTRY.nearest(key, TPASTRY.leaves())
				if TPASTRY.diff(n, key) < TPASTRY.diff(me, key) then
					return TPASTRY.try_route(msg, key, n)
				end
			else
				local row, col = TPASTRY.row_col(key)
				if TPASTRY.routing_table[row][col] then
					return TPASTRY.try_route(msg, key, TPASTRY.routing_table[row][col])
				else
					for r = row, key_size - 1 do 
						for _, n in pairs(TPASTRY.routing_table[r]) do
							if TPASTRY.diff(n, key) < TPASTRY.diff(me, key) then
								return TPASTRY.try_route(msg, key, n)
							end
						end
					end
					for _, n in pairs(TPASTRY.leaves()) do
						if TPASTRY.shared_prefix_length(n.id, key) >= row and TPASTRY.diff(n, key) < TPASTRY.diff(me, key) then
							return TPASTRY.try_route(msg, key, n)
						end
					end
				end
			end
		end		
		return me, TPASTRY.receive(msg, key)	
	end,

	receive = function(msg, key)
		if msg.typ == "#test#" then 
			--log:print("message #"..actions .. "\tmessage received") 
			if msg.origin then rpc.call(msg.origin, {'TPASTRY.delivered', key, me, msg.count_hops, msg.time}) end
		end
	end,

	delivered = function(key, dest, hops, time_start)
		--local correct = TPASTRY.check_correctness(key, dest)
		local time_end = misc.time()
		local elapsed = time_end - tonumber(time_start)
		local res = ""
		--if correct then 
--				res = "CORRECT_FOUND "
--			elseif correct == 0 then
--				res = "CORRECT_NOT_FOUND"
--			else res = "CHECK_FAILED" end
		local msg = table.concat({key.." KEY_OWNER "..dest.id.." HOPS "..hops.." HOPS ".." DELAY "..elapsed})
		log:print(res,msg)
	end,

	precompute_resp_node = function(keys)
		local ids = TPASTRY.hash_all()
		ids[#ids+1] = me.id
		for i,k in pairs(keys) do
			TPASTRY.rank_clockwise(ids, k)
			TPASTRY.responsible[k] = ids[1]
		end
	end,

	display_responsible = function()
		log:print("RESPONSIBLE_NODES: ")
		for i,v in pairs(TPASTRY.responsible) do
			log:print(table.concat({i," ", v,"\n"}))
		end	
	end,

	check_correctness = function(key, node)	
		if not TPASTRY.responsible[key] then return -1
			else 
				if TPASTRY.responsible[key] == node.id then return 1 else return 0 end
		end		
	end,
	
	start_lookup = function()
	--start lookups		
		if TPASTRY.lookup_token then
			log:print("Launching lookups")
				for i,v in ipairs(TPASTRY.keys) do
					log:print("LOOKUP_START ".. v)
					TPASTRY.route({typ = "#test#", origin = me.peer}, v, false)
				end
			if tonumber(job.position) < #job.get_live_nodes() then
				local next_ind = job.position+1
				local ok = rpc.acall(job.get_live_nodes()[next_ind], {'TPASTRY.token_callback', next_ind})
				local try = 0
				while not ok do
					try = try+1
					if try <= 5 then
						ok = rpc.acall(job.get_live_nodes()[next_ind], {'TPASTRY.token_callback', next_ind})
					else log:print("lookup: cannot contact the next node to pass the token") return end
				end
				if ok then log:print("lookup: firing signal", next_ind) end
			end
		end
	end,

	token_callback = function(pos)
  	events.fire(tostring(pos), true)
	end,
	
-------------------------------------------------------------------------------
-- T-Pastry
-------------------------------------------------------------------------------
		--initialise given view from PSS view
	init = function(size)		
		local buffer = misc.dup(PSS.view)
		TPASTRY.remove_dup(buffer)
		TPASTRY.remove_node(buffer,me)
		TPASTRY.keep_n(buffer,size)
		return buffer
	end,
	
	init_all_views = function()
		TPASTRY.leaves_decreasing = TPASTRY.init(leaf_size/2)
		TPASTRY.leaves_increasing = TPASTRY.init(leaf_size/2)
		for i = 0, key_size - 1 do TPASTRY.routing_table[i] = {} end
		TPASTRY.succ_view = TPASTRY.init(TPASTRY.s)
		TPASTRY.pred_view = TPASTRY.init(TPASTRY.s)
		TPASTRY.check_convergence(TPASTRY.cycle_succ, "init")
	end,
	
	--select random peer from PSS view
	select_peer_pss = function()
		if #PSS.view > 0 then
			local i 
			repeat i = math.random(#PSS.view)
			until not TPASTRY.same_node(PSS.view[i], me)
			local partner = PSS.view[i]
			return partner
		end
	end,

--select random peer from a view
	select_peer_view = function(view)
		local stale = TPASTRY.find_stale_node(view)
		if stale then return stale else return  misc.random_pick(view) end
	end,

	create_message = function(partner)
		local merged =  TPASTRY.merge(TPASTRY.succ_view, TPASTRY.pred_view, PSS.view,  TPASTRY.flatten(TPASTRY.routing_table))
		TPASTRY.remove_dup(merged)
		merged[#merged+1] = me
		TPASTRY.remove_node(merged, partner)
		return TPASTRY.select_by_age(merged, TPASTRY.m)
		--return merged
	end,
	
	update_in_leaf_set = function(received)
		TPASTRY.in_leaves_lock:lock()
		TPASTRY.icreasing_leaves = TPASTRY.merge(TPASTRY.leaves_increasing, PSS.view,TPASTRY.succ_view)	
		TPASTRY.remove_node(TPASTRY.leaves_increasing,me)
		TPASTRY.remove_dup(TPASTRY.leaves_increasing)
		if received then
			TPASTRY.leaves_increasing = TPASTRY.update_age_merge(received,TPASTRY.leaves_increasing)
		end
		TPASTRY.rank_clockwise(TPASTRY.leaves_increasing,me)
		TPASTRY.keep_n(TPASTRY.leaves_increasing , leaf_size/2)
		TPASTRY.in_leaves_lock:unlock()
	end,
	
	update_de_leaf_set = function(received)
		TPASTRY.de_leaves_lock:lock()
		TPASTRY.leaves_decreasing = TPASTRY.merge(TPASTRY.leaves_decreasing,PSS.view,TPASTRY.pred_view)
		TPASTRY.remove_node(TPASTRY.leaves_decreasing,me)
		TPASTRY.remove_dup(TPASTRY.leaves_decreasing)
		if received then
			TPASTRY.leaves_decreasing = TPASTRY.update_age_merge(received,TPASTRY.leaves_decreasing)
		end
		TPASTRY.rank_c_clockwise(TPASTRY.leaves_decreasing,me)
		TPASTRY.keep_n(TPASTRY.leaves_decreasing, leaf_size/2)
		TPASTRY.de_leaves_lock:unlock()
	end,
	
	

	update_prefix_table = function(received)
		local matched = {}
		for i = 0, #TPASTRY.routing_table do
			matched[i] = {}
		end
		local buffer =  TPASTRY.merge(PSS.view,TPASTRY.pred_view,TPASTRY.succ_view)
		buffer = TPASTRY.update_age_merge(received,buffer)
		TPASTRY.rt_lock:lock()
		for i,v in ipairs(buffer) do
			local row, col = TPASTRY.row_col(v.id)
			if TPASTRY.routing_table[row] then
				if not TPASTRY.routing_table[row][col] then
					TPASTRY.routing_table[row][col] = v				
				else
					if TPASTRY.routing_table[row][col].id == v.id then
						matched[row][col] = true
						TPASTRY.update_age(TPASTRY.routing_table[row][col],v)
					end
				end
			end
		end
		for i = 0, key_size/4 do
			for j = 0, 2^b-1 do
				if TPASTRY.routing_table[i] and TPASTRY.routing_table[i][j] then
					if not matched[i] or not matched[i][j]  then 
						TPASTRY.routing_table[i][j].age = TPASTRY.routing_table[i][j].age+1
					end
				end
			end
		end
		TPASTRY.rt_lock:unlock()
	end,
	
	merge_view_pred = function(received)
		TPASTRY.pred_view_lock:lock()
		TPASTRY.pred_view = TPASTRY.update_age_merge(received, TPASTRY.pred_view)
		TPASTRY.remove_dup(TPASTRY.pred_view)
		TPASTRY.rank_c_clockwise(TPASTRY.pred_view,me)
		TPASTRY.keep_n(TPASTRY.pred_view, TPASTRY.s)
		TPASTRY.pred_view_lock:unlock()
	end,
	
	
	merge_view_succ = function(received)
		TPASTRY.succ_view_lock:lock()
		TPASTRY.succ_view = TPASTRY.update_age_merge(received,TPASTRY.succ_view)
		TPASTRY.remove_dup(TPASTRY.succ_view)
		TPASTRY.rank_clockwise(TPASTRY.succ_view,me)
		TPASTRY.keep_n(TPASTRY.succ_view, TPASTRY.s)
		TPASTRY.succ_view_lock:unlock()
	end,

	passive_thread_succ = function(received,sender)
		local buffer = TPASTRY.create_message(sender)
		TPASTRY.update_in_leaf_set(received)
		TPASTRY.update_de_leaf_set(received)
		TPASTRY.update_prefix_table(received)
		TPASTRY.merge_view_succ(received)
		return buffer
	end,
	
	
	passive_thread_pred = function(received,sender)
		local buffer = TPASTRY.create_message(sender)
		TPASTRY.update_de_leaf_set(received)
		TPASTRY.update_in_leaf_set(received)
		TPASTRY.update_prefix_table(received)
		TPASTRY.merge_view_pred(received)
		return buffer
	end,
	
	select_partner = function(partner_select_code, loc_cycle, view)
		if partner_select_code == 0 then --alternating
			if loc_cycle <= 2 then return TPASTRY.select_peer_pss()
			else 
				if loc_cycle%2==0 then return TPASTRY.select_peer_pss() else return TPASTRY.select_peer_view(view) end
			end
		elseif partner_select_code == 1 then --only pss
			return TPASTRY.select_peer_pss()
		elseif partner_select_code == 2 then --only view
			return TPASTRY.select_peer_view(view)
		end	
	end,

	active_thread_succ = function()	
		TPASTRY.cycle_succ_lock:lock()
		local loc_cycle = TPASTRY.cycle_succ+1
		TPASTRY.cycle_succ = TPASTRY.cycle_succ+1
		TPASTRY.cycle_succ_lock:unlock()
		local partner = TPASTRY.select_partner(PARTNER_SELECT, loc_cycle,TPASTRY.succ_view)
		--log:print("selected partner", partner.id)
		if not partner then log:print("TPASTRY.active_thread_succ: no partner selected") return end 
		local buffer = TPASTRY.create_message(partner)
		local try = 0
		local ok, res = rpc.acall(partner.peer, {'TPASTRY.passive_thread_succ', buffer, me})
		while not ok do
			try = try + 1
			if try <= 2 then
				log:print("TPASTRY.active_thread_succ: no response from: "..partner.id.. ": "..tostring(res).." => try again")
				ok, res = rpc.acall(partner.peer, {'TPASTRY.passive_thread_succ', buffer, me})
			else
				log:print("TPASTRY.active_thread_succ no response from: "..partner.id..": "..tostring(res).."  => removing it from view")
				TPASTRY.remove_failed_node(partner)
				TPASTRY.update_in_leaf_set()
				TPASTRY.update_de_leaf_set()
				break
			end
		end
		if ok then
			local received = res[1]
			TPASTRY.update_in_leaf_set(received)
			TPASTRY.update_prefix_table(received)
			TPASTRY.merge_view_succ(received)
			resource_stats()
			TPASTRY.precompute_views()
			TPASTRY.check_convergence(loc_cycle,"active_thread_succ")
			--TPASTRY.debug(loc_cycle)
		end
	end,
	
	active_thread_pred = function()	
		TPASTRY.cycle_pred_lock:lock()
		local loc_cycle = TPASTRY.cycle_pred+1
		TPASTRY.cycle_pred = TPASTRY.cycle_pred+1
		TPASTRY.cycle_pred_lock:unlock()
		local partner =  TPASTRY.select_partner(PARTNER_SELECT, loc_cycle,TPASTRY.pred_view)
		--log:print("selected partner", partner.id)
		if not partner then log:print("TPASTRY.active_thread_pred: no partner selected") return end 
		local buffer = TPASTRY.create_message(partner)
		local try = 0
		local ok, res = rpc.acall(partner.peer, {'TPASTRY.passive_thread_pred', buffer, me})
		while not ok do
			try = try + 1
			if try <= 2 then
				log:print("TPASTRY.active_thread_pred: no response from: "..partner.id.. ": "..tostring(res).." => try again")
				ok, res = rpc.acall(partner.peer, {'TPASTRY.passive_thread_pred', buffer, me})
			else
				log:print("TPASTRY.active_thread_pred no response from: "..partner.id..": "..tostring(res).."  => removing it from view")
				TPASTRY.remove_failed_node(partner)
				TPASTRY.update_in_leaf_set()
				TPASTRY.update_de_leaf_set()
				break
			end
		end
		if ok then
			local received = res[1]
			TPASTRY.update_de_leaf_set(received)
			TPASTRY.update_prefix_table(received)
			TPASTRY.merge_view_pred(received)
			resource_stats()
			TPASTRY.precompute_views()
			TPASTRY.check_convergence(loc_cycle,"active_thread_pred")
			--TPASTRY.debug(loc_cycle)
		end
	end,
}

-------------------------------------------------------------------------------
-- Main loop
-------------------------------------------------------------------------------
function terminator()
  events.sleep(max_time)
  os.exit()
end

function resource_stats()
	--log:print("MEMORY_USED_Kb ", gcinfo())
	local ts,tr = socket.stats()
	local tot_KB_sent=misc.bitcalc(ts).kilobytes
	local tot_KB_recv=misc.bitcalc(tr).kilobytes
	--log:print("BANDWIDTH_TOTAL ",tot_KB_sent, tot_KB_recv)
	--log:print("BANDWIDTH_RATE  ", (tot_KB_sent - bytesSent )/STATS_PERIOD, (tot_KB_recv - bytesReceived) /STATS_PERIOD)
	bytesSent = tot_KB_sent
	bytesReceived = tot_KB_recv
end

function lookup_test()
	local key = compute_id(math.random(100000000))
	log:print("LOOKUP_START ".. key)
	TPASTRY.route({typ = "#test#", origin = me.peer}, key, false)
end


function main()
-- this thread will be in charge of killing the node after max_time seconds
	events.thread(terminator)
	
-- init random number generator
	math.randomseed(job.position*os.time())
	
-- wait for all nodes to start up (conservative)
  	events.sleep(1)
  	
-- desynchronize the nodes
	local desync_wait = (GOSSIP_TIME * math.random())
  log:print("waiting for "..desync_wait.." to desynchronize")
	events.sleep(desync_wait)
	
--	precompute view for convergence test
	TPASTRY.precompute_views()	
	
-- initialize pss
	PSS.pss_init()
	events.sleep(5)
	pss_thread = events.periodic(PSS_SHUFFLE_PERIOD, PSS.pss_active_thread) 
	events.sleep(100)
	
--initializing TMAN views	
	TPASTRY.init_all_views()
	events.sleep(2)	
	log:print("VIEW_CONSTRUCTION_START_TIME", misc.time())	
	tpastry_thread = events.periodic(GOSSIP_TIME, {TPASTRY.active_thread_succ,TPASTRY.active_thread_pred, lookup_test})

	--events.sleep(500)
	--events.kill({tpastry_thread, pss_thread})
	--events.sleep(10)


--generating keys and launching lookups
	if TPASTRY_LOOKUP then
		for i = 1, 50 do
			TPASTRY.keys[#TPASTRY.keys+1] = compute_id(math.random(100000000))
		end
		TPASTRY.precompute_resp_node(TPASTRY.keys)
		events.sleep(10)
		--TPASTRY.display_responsible()	
		events.thread(function()
		TPASTRY.lookup_token = events.wait(tostring(job.position))
		TPASTRY.start_lookup()
		end)	
		if tonumber(job.position) == 1 then events.fire(tostring(job.position), true) end
	end
	
end

events.thread(main)
events.loop()

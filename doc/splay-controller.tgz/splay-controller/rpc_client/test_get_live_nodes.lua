
require"splay.base"

function live_nodes_tester()
	while events.yield() do
		local nodes = job.get_live_nodes() --OR the old form: job.nodes
		log:print("Position: ".. job.position .." live_nodes:"..#nodes)
		events.sleep(5)
	end
	os.exit()
end
events.thread(live_nodes_tester)
events.loop()


BASE_IP="172.17.0."
FILE=$1
DEST=$2
machines=( $(seq 2 11) 19 28 ) 

for m in ${machines[@]} 
do
	echo $BASE_IP$m
	scp -p $FILE  splayd@$BASE_IP$m:$DEST
done


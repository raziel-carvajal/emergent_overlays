#!/bin/bash -i
BASE_IP="172.17.0."
cmd=$1

machines=( $(seq 28 28) )

for m in ${machines[@]}
do
        echo -n "connecting to machine: $BASE_IP$m and sending the command: <$cmd> "
	echo ""
        ssh splayd@$BASE_IP$m bash <<< "$cmd"
        echo ""
done

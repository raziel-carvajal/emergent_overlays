#!/bin/bash -i
SPLAY_INSTALL_DIR="/home/splayd/splay/src/daemon"

function usage {
  echo "Usage: <script name> <number of splayd already deployed per machine>"
  exit 1
}
if [ $# -lt 2 ] ; then
  usage
fi

SPLAYDS_PER_MACHINE=$1
SPLAY_CTRL_IP=$2

echo "killing daemons" 
killall lua

# This is only to keep the template directory coherent to the others.
cd ~/workspace/local_splay_cluster/template/
cp $SPLAY_INSTALL_DIR/jobd_no_sandbox.lua
rm jobd.lua 

# remove the current jobd.lua from the deployed directores and copy the jobd_no_sandbox.lua to it 
LOCALADDRESS=$(hostname -I|sed s/[.]/_/g| sed -e's/[[:space:]]*$//' )
echo "LOCALADDRESS : ${LOCALADDRESS}"
LOCALHOSTNAME=splayd_"$LOCALADDRESS"
echo "LOCALHOSTNAME : ${LOCALHOSTNAME}"
for ((i = 1 ; i <=$SPLAYDS_PER_MACHINE; i++ ))
do
  rm "$LOCALHOSTNAME"_$i/jobd.lua
  cp $SPLAY_INSTALL_DIR/jobd_no_sandbox.lua hosts/"$LOCALHOSTNAME"_$i
done


# This will start all the splay daemons
for ((j = 1 ; j <= $SPLAYDS_PER_MACHINE; j++))
do
  startport=$[12000+1000*($j+1)]
  endport=$[$startport+999] #each splayd has 1000 ports in range
  echo $startport $endport
  cd hosts/"$LOCALHOSTNAME"_${j}/
  ctrlport=$[10999+$[ ( $RANDOM % 10 )  + 1 ]] #first avail is 11000
  #echo "Starting splayd host_${BASE}_${j} ${SPLAY_CTRL_IP} $ctrlport $startport $endport"
  echo "Starting splayd ${LOCALHOSTNAME}_$j ${SPLAY_CTRL_IP} $ctrlport $startport $endport"
  lua splayd.lua "$LOCALHOSTNAME"_$j ${SPLAY_CTRL_IP} $ctrlport $startport $endport &
  cd ../../;
  sleep 0.1
done

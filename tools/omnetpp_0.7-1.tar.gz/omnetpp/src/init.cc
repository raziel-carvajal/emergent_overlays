/*
 * Copyright (c) 2010, Andras Varga and Opensim Ltd.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Opensim Ltd. nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Andras Varga or Opensim Ltd. BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <R.h>
#include <Rdefines.h>
#include <R_ext/Rdynload.h>

#include "loadDataset.h"
#include "loadVectors.h"
#include "generateIndexFiles.h"

extern "C" {

/*
R_CMethodDef cMethods[] = {
        {"cLoadDataset", (DL_FUNC)&cLoadDataset, 2, {STRSXP, INTSXP}},
        {NULL, NULL, 0}
};
*/

R_CallMethodDef callMethods[] = {
        {"callLoadDataset", (DL_FUNC)&callLoadDataset, 2},
        {"callLoadVectors", (DL_FUNC)&callLoadVectors, 2},
        {"callGenerateIndexFiles", (DL_FUNC)&callGenerateIndexFiles, 2},
        {NULL, NULL, 0}
};

void R_init_omnetpp(DllInfo *info)
{
    R_registerRoutines(info, NULL, callMethods, NULL, NULL);
}

}

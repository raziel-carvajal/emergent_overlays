/*
 * Copyright (c) 2010, Andras Varga and Opensim Ltd.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Opensim Ltd. nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Andras Varga or Opensim Ltd. BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdlib.h>
#include <locale.h>

#include "channel.h"
#include "vectorfilewriter.h"
#include "stringutil.h"

#define VECTOR_FILE_VERSION 2

#define LL  INT64_PRINTF_FORMAT  /* abbreviation */

#ifdef CHECK
#undef CHECK
#endif

USING_NAMESPACE

#define CHECK(fprintf)    if (fprintf<0) throw opp_runtime_error("Cannot write output vector file `%s'", fileName.c_str())

VectorFileWriterNode::VectorFileWriterNode(const char *fileName, const char *fileHeader)
{
    f = NULL;
    this->prec = DEFAULT_PRECISION;
    this->fileName = fileName;
    this->fileHeader = (fileHeader ? fileHeader : "");
}

VectorFileWriterNode::~VectorFileWriterNode()
{
}

Port *VectorFileWriterNode::addVector(const VectorResult &vector)
{
    ports.push_back(Pair(vector.vectorId, vector.moduleNameRef->c_str(), vector.nameRef->c_str(), vector.columns.c_str(), this));
    return &(ports.back().port);
}

bool VectorFileWriterNode::isReady() const
{
    for (PortVector::const_iterator it=ports.begin(); it!=ports.end(); it++)
        if (it->port()->length()>0)
            return true;
    return false;
}

void VectorFileWriterNode::process()
{
    // open file if needed
    if (!f)
    {
        f = fopen(fileName.c_str(), "w");
        if (!f)
            throw opp_runtime_error("cannot open `%s' for write", fileName.c_str());

        setlocale(LC_NUMERIC, "C");

        // print file header and vector declarations
        CHECK(fprintf(f,"%s\n\n", fileHeader.c_str()));
        CHECK(fprintf(f,"version %d\n", VECTOR_FILE_VERSION));

        for (PortVector::iterator it=ports.begin(); it!=ports.end(); it++)
            CHECK(fprintf(f, "vector %d  %s  %s  %s\n", it->id,
                             QUOTE(it->moduleName.c_str()),
                             QUOTE(it->name.c_str()), it->columns.c_str()));
    }

    for (PortVector::iterator it=ports.begin(); it!=ports.end(); it++)
    {
        Channel *chan = it->port();
        int n = chan->length();
        std::string &columns = it->columns;
        int colno = columns.size();
        Datum a;
        char buf[64];
        char *endp;

        if (colno == 2 && columns[0] == 'T' && columns[1] == 'V')
        {
            for (int i=0; i<n; i++)
            {
                chan->read(&a,1);
                if (a.xp.isNil())
                {
                    CHECK(fprintf(f,"%d\t%.*g\t%.*g\n", it->id, prec, a.x, prec, a.y));
                }
                else
                {
                    CHECK(fprintf(f,"%d\t%s\t%.*g\n", it->id, BigDecimal::ttoa(buf, a.xp, endp), prec, a.y));
                }
            }
        }
        else if (colno == 3 && columns[0] == 'E' && columns[1] == 'T' && columns[2] == 'V')
        {
            for (int i=0; i<n; i++)
            {
                chan->read(&a,1);
                if (a.xp.isNil())
                {
                    CHECK(fprintf(f,"%d\t%"LL"d\t%.*g\t%.*g\n", it->id, a.eventNumber, prec, a.x, prec, a.y));
                }
                else
                {
                    CHECK(fprintf(f,"%d\t%"LL"d\t%s\t%.*g\n", it->id, a.eventNumber, BigDecimal::ttoa(buf, a.xp, endp), prec, a.y));
                }
            }
        }
        else
        {
            for (int i=0; i<n; i++)
            {
                chan->read(&a,1);
                CHECK(fprintf(f,"%d",it->id));
                for (int j=0; j<colno; ++j)
                {
                    CHECK(fputc('\t', f));
                    switch (columns[j])
                    {
                    case 'T':
                        if (a.xp.isNil())
                        {
                            CHECK(fprintf(f,"%.*g", prec, a.x));
                        }
                        else
                        {
                            CHECK(fprintf(f, "%s", BigDecimal::ttoa(buf, a.xp, endp)));
                        }
                        break;
                    case 'V': CHECK(fprintf(f,"%.*g", prec, a.y)); break;
                    case 'E': CHECK(fprintf(f,"%"LL"d", a.eventNumber)); break;
                    default: throw opp_runtime_error("unknown column type: '%c' while writing %s", columns[j], fileName.c_str());
                    }
                }
                CHECK(fputc('\n', f));

            }
        }
    }
}

bool VectorFileWriterNode::isFinished() const
{
    for (PortVector::const_iterator it=ports.begin(); it!=ports.end(); it++)
        if (!it->port()->isClosing() || it->port()->length()>0)
            return false;
    return true;
}

//-------

const char *VectorFileWriterNodeType::getDescription() const
{
    return "Writes the output (several streams) into an output vector file.";
}

void VectorFileWriterNodeType::getAttributes(StringMap& attrs) const
{
    attrs["filename"] = "name of the output vector file (.vec)";
}

Node *VectorFileWriterNodeType::create(DataflowManager *mgr, StringMap& attrs) const
{
    checkAttrNames(attrs);

    const char *fileName = attrs["filename"].c_str();

    Node *node = new VectorFileWriterNode(fileName);
    node->setNodeType(this);
    mgr->addNode(node);
    return node;
}

Port *VectorFileWriterNodeType::getPort(Node *node, const char *portname) const
{
    // vector id is used as port name
    VectorFileWriterNode *node1 = dynamic_cast<VectorFileWriterNode *>(node);
    VectorResult vector;
    std::string moduleName = "n/a", name = "n/a";
    vector.vectorId = atoi(portname);  // FIXME check it's numeric at all
    vector.moduleNameRef = &moduleName;
    vector.nameRef = &name;
    vector.columns = "TV";             // old vector file format
    return node1->addVector(vector);
}


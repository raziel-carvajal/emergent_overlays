//
// Generated file, do not edit! Created by nedtool 4.6 from inet/linklayer/csmaca/CsmaCaMacFrame.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "CsmaCaMacFrame_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}



namespace inet {

// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

Register_Class(CsmaCaMacFrame);

CsmaCaMacFrame::CsmaCaMacFrame(const char *name, int kind) : ::cPacket(name,kind)
{
}

CsmaCaMacFrame::CsmaCaMacFrame(const CsmaCaMacFrame& other) : ::cPacket(other)
{
    copy(other);
}

CsmaCaMacFrame::~CsmaCaMacFrame()
{
}

CsmaCaMacFrame& CsmaCaMacFrame::operator=(const CsmaCaMacFrame& other)
{
    if (this==&other) return *this;
    ::cPacket::operator=(other);
    copy(other);
    return *this;
}

void CsmaCaMacFrame::copy(const CsmaCaMacFrame& other)
{
    this->transmitterAddress_var = other.transmitterAddress_var;
    this->receiverAddress_var = other.receiverAddress_var;
}

void CsmaCaMacFrame::parsimPack(cCommBuffer *b)
{
    ::cPacket::parsimPack(b);
    doPacking(b,this->transmitterAddress_var);
    doPacking(b,this->receiverAddress_var);
}

void CsmaCaMacFrame::parsimUnpack(cCommBuffer *b)
{
    ::cPacket::parsimUnpack(b);
    doUnpacking(b,this->transmitterAddress_var);
    doUnpacking(b,this->receiverAddress_var);
}

MACAddress& CsmaCaMacFrame::getTransmitterAddress()
{
    return transmitterAddress_var;
}

void CsmaCaMacFrame::setTransmitterAddress(const MACAddress& transmitterAddress)
{
    this->transmitterAddress_var = transmitterAddress;
}

MACAddress& CsmaCaMacFrame::getReceiverAddress()
{
    return receiverAddress_var;
}

void CsmaCaMacFrame::setReceiverAddress(const MACAddress& receiverAddress)
{
    this->receiverAddress_var = receiverAddress;
}

class CsmaCaMacFrameDescriptor : public cClassDescriptor
{
  public:
    CsmaCaMacFrameDescriptor();
    virtual ~CsmaCaMacFrameDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(CsmaCaMacFrameDescriptor);

CsmaCaMacFrameDescriptor::CsmaCaMacFrameDescriptor() : cClassDescriptor("inet::CsmaCaMacFrame", "cPacket")
{
}

CsmaCaMacFrameDescriptor::~CsmaCaMacFrameDescriptor()
{
}

bool CsmaCaMacFrameDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<CsmaCaMacFrame *>(obj)!=NULL;
}

const char *CsmaCaMacFrameDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int CsmaCaMacFrameDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 2+basedesc->getFieldCount(object) : 2;
}

unsigned int CsmaCaMacFrameDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISCOMPOUND,
        FD_ISCOMPOUND,
    };
    return (field>=0 && field<2) ? fieldTypeFlags[field] : 0;
}

const char *CsmaCaMacFrameDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "transmitterAddress",
        "receiverAddress",
    };
    return (field>=0 && field<2) ? fieldNames[field] : NULL;
}

int CsmaCaMacFrameDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='t' && strcmp(fieldName, "transmitterAddress")==0) return base+0;
    if (fieldName[0]=='r' && strcmp(fieldName, "receiverAddress")==0) return base+1;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *CsmaCaMacFrameDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "MACAddress",
        "MACAddress",
    };
    return (field>=0 && field<2) ? fieldTypeStrings[field] : NULL;
}

const char *CsmaCaMacFrameDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int CsmaCaMacFrameDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacFrame *pp = (CsmaCaMacFrame *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string CsmaCaMacFrameDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacFrame *pp = (CsmaCaMacFrame *)object; (void)pp;
    switch (field) {
        case 0: {std::stringstream out; out << pp->getTransmitterAddress(); return out.str();}
        case 1: {std::stringstream out; out << pp->getReceiverAddress(); return out.str();}
        default: return "";
    }
}

bool CsmaCaMacFrameDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacFrame *pp = (CsmaCaMacFrame *)object; (void)pp;
    switch (field) {
        default: return false;
    }
}

const char *CsmaCaMacFrameDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 0: return opp_typename(typeid(MACAddress));
        case 1: return opp_typename(typeid(MACAddress));
        default: return NULL;
    };
}

void *CsmaCaMacFrameDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacFrame *pp = (CsmaCaMacFrame *)object; (void)pp;
    switch (field) {
        case 0: return (void *)(&pp->getTransmitterAddress()); break;
        case 1: return (void *)(&pp->getReceiverAddress()); break;
        default: return NULL;
    }
}

Register_Class(CsmaCaMacAckFrame);

CsmaCaMacAckFrame::CsmaCaMacAckFrame(const char *name, int kind) : ::inet::CsmaCaMacFrame(name,kind)
{
}

CsmaCaMacAckFrame::CsmaCaMacAckFrame(const CsmaCaMacAckFrame& other) : ::inet::CsmaCaMacFrame(other)
{
    copy(other);
}

CsmaCaMacAckFrame::~CsmaCaMacAckFrame()
{
}

CsmaCaMacAckFrame& CsmaCaMacAckFrame::operator=(const CsmaCaMacAckFrame& other)
{
    if (this==&other) return *this;
    ::inet::CsmaCaMacFrame::operator=(other);
    copy(other);
    return *this;
}

void CsmaCaMacAckFrame::copy(const CsmaCaMacAckFrame& other)
{
}

void CsmaCaMacAckFrame::parsimPack(cCommBuffer *b)
{
    ::inet::CsmaCaMacFrame::parsimPack(b);
}

void CsmaCaMacAckFrame::parsimUnpack(cCommBuffer *b)
{
    ::inet::CsmaCaMacFrame::parsimUnpack(b);
}

class CsmaCaMacAckFrameDescriptor : public cClassDescriptor
{
  public:
    CsmaCaMacAckFrameDescriptor();
    virtual ~CsmaCaMacAckFrameDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(CsmaCaMacAckFrameDescriptor);

CsmaCaMacAckFrameDescriptor::CsmaCaMacAckFrameDescriptor() : cClassDescriptor("inet::CsmaCaMacAckFrame", "inet::CsmaCaMacFrame")
{
}

CsmaCaMacAckFrameDescriptor::~CsmaCaMacAckFrameDescriptor()
{
}

bool CsmaCaMacAckFrameDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<CsmaCaMacAckFrame *>(obj)!=NULL;
}

const char *CsmaCaMacAckFrameDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int CsmaCaMacAckFrameDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 0+basedesc->getFieldCount(object) : 0;
}

unsigned int CsmaCaMacAckFrameDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    return 0;
}

const char *CsmaCaMacAckFrameDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    return NULL;
}

int CsmaCaMacAckFrameDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *CsmaCaMacAckFrameDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    return NULL;
}

const char *CsmaCaMacAckFrameDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int CsmaCaMacAckFrameDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacAckFrame *pp = (CsmaCaMacAckFrame *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string CsmaCaMacAckFrameDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacAckFrame *pp = (CsmaCaMacAckFrame *)object; (void)pp;
    switch (field) {
        default: return "";
    }
}

bool CsmaCaMacAckFrameDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacAckFrame *pp = (CsmaCaMacAckFrame *)object; (void)pp;
    switch (field) {
        default: return false;
    }
}

const char *CsmaCaMacAckFrameDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    return NULL;
}

void *CsmaCaMacAckFrameDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacAckFrame *pp = (CsmaCaMacAckFrame *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}

Register_Class(CsmaCaMacDataFrame);

CsmaCaMacDataFrame::CsmaCaMacDataFrame(const char *name, int kind) : ::inet::CsmaCaMacFrame(name,kind)
{
    this->priority_var = 0;
}

CsmaCaMacDataFrame::CsmaCaMacDataFrame(const CsmaCaMacDataFrame& other) : ::inet::CsmaCaMacFrame(other)
{
    copy(other);
}

CsmaCaMacDataFrame::~CsmaCaMacDataFrame()
{
}

CsmaCaMacDataFrame& CsmaCaMacDataFrame::operator=(const CsmaCaMacDataFrame& other)
{
    if (this==&other) return *this;
    ::inet::CsmaCaMacFrame::operator=(other);
    copy(other);
    return *this;
}

void CsmaCaMacDataFrame::copy(const CsmaCaMacDataFrame& other)
{
    this->priority_var = other.priority_var;
}

void CsmaCaMacDataFrame::parsimPack(cCommBuffer *b)
{
    ::inet::CsmaCaMacFrame::parsimPack(b);
    doPacking(b,this->priority_var);
}

void CsmaCaMacDataFrame::parsimUnpack(cCommBuffer *b)
{
    ::inet::CsmaCaMacFrame::parsimUnpack(b);
    doUnpacking(b,this->priority_var);
}

int CsmaCaMacDataFrame::getPriority() const
{
    return priority_var;
}

void CsmaCaMacDataFrame::setPriority(int priority)
{
    this->priority_var = priority;
}

class CsmaCaMacDataFrameDescriptor : public cClassDescriptor
{
  public:
    CsmaCaMacDataFrameDescriptor();
    virtual ~CsmaCaMacDataFrameDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(CsmaCaMacDataFrameDescriptor);

CsmaCaMacDataFrameDescriptor::CsmaCaMacDataFrameDescriptor() : cClassDescriptor("inet::CsmaCaMacDataFrame", "inet::CsmaCaMacFrame")
{
}

CsmaCaMacDataFrameDescriptor::~CsmaCaMacDataFrameDescriptor()
{
}

bool CsmaCaMacDataFrameDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<CsmaCaMacDataFrame *>(obj)!=NULL;
}

const char *CsmaCaMacDataFrameDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int CsmaCaMacDataFrameDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 1+basedesc->getFieldCount(object) : 1;
}

unsigned int CsmaCaMacDataFrameDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
    };
    return (field>=0 && field<1) ? fieldTypeFlags[field] : 0;
}

const char *CsmaCaMacDataFrameDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "priority",
    };
    return (field>=0 && field<1) ? fieldNames[field] : NULL;
}

int CsmaCaMacDataFrameDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='p' && strcmp(fieldName, "priority")==0) return base+0;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *CsmaCaMacDataFrameDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
    };
    return (field>=0 && field<1) ? fieldTypeStrings[field] : NULL;
}

const char *CsmaCaMacDataFrameDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int CsmaCaMacDataFrameDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacDataFrame *pp = (CsmaCaMacDataFrame *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string CsmaCaMacDataFrameDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacDataFrame *pp = (CsmaCaMacDataFrame *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getPriority());
        default: return "";
    }
}

bool CsmaCaMacDataFrameDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacDataFrame *pp = (CsmaCaMacDataFrame *)object; (void)pp;
    switch (field) {
        case 0: pp->setPriority(string2long(value)); return true;
        default: return false;
    }
}

const char *CsmaCaMacDataFrameDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    };
}

void *CsmaCaMacDataFrameDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    CsmaCaMacDataFrame *pp = (CsmaCaMacDataFrame *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}

} // namespace inet

